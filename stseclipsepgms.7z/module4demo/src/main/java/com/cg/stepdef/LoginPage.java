package com.cg.stepdef;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginPage {

	public LoginPage(WebDriver driver) {
		PageFactory.initElements(driver, this);

	}
	@FindBy(xpath="/html/body/div/header/ul/li[1]/a")
	WebElement home;
	public void clickHome() {
		home.click();
	}
	@FindBy(xpath="/html/body/div/header/ul/li[3]/a")
	WebElement contact;
	public void clickContactUs() {
		contact.click();
	}
	@FindBy(xpath="/html/body/div/header/ul/li[2]/a")
	WebElement register;
	public void clickRegister() {
    register.click();
		
	}
	@FindBy(xpath="/html/body/form/table/tbody/tr[3]/td[2]/input")
	WebElement enumb;
	@FindBy(xpath="/html/body/form/table/tbody/tr[2]/td[2]/input")
	WebElement ename;
	public void Id() {
		ename.sendKeys("kaviya");
		enumb.sendKeys("");
	}
	
	@FindBy(xpath="/html/body/form/table/tbody/tr[9]/td/p/input[1]")
	WebElement submit;
	
	public void clickSubmit() {

		submit.click();	
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}