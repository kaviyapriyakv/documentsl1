package com.cg.stepdef;
import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class LoginSteps {
	WebDriver driver;
	LoginPage login;
	@Given("^User is on Registration Page for Infoway Tech India$")
	public void user_is_on_Registration_Page_for_Infoway_Tech_India() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\KPRIYAKV\\chromedriver_win32\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.get("file:///C:/Users/KPRIYAKV/Downloads/SET%20A_HTML%20&%20JS%20Pages/Home.html");
		login = new LoginPage(driver);	
	}

	@When("^user clicks on Home link then he should be in the same page\\.$")
	public void user_clicks_on_Home_link_then_he_should_be_in_the_same_page() throws Throwable {
	    login.clickHome();
	   Assert.assertEquals("Home Page",driver.getTitle());
	    Thread.sleep(5000);
		
	}

	@When("^user clicks on Contact Us link$")
	public void user_clicks_on_Contact_Us_link() throws Throwable {
		login.clickContactUs();
		    
	}

	@Then("^the user must get the title and the title should be Infoway Tech India$")
	public void the_user_must_get_the_title_and_the_title_should_be_Infoway_Tech_India() throws Throwable {
		 Assert.assertEquals("Contact Us",driver.getTitle());
		 driver.navigate().back();
	}

	@When("^user clicks on Registration link$")
	public void user_clicks_on_Registration_link() throws Throwable {
	   login.clickRegister();
	}

	@Then("^the user must validate the title should be Infoway Tech India\\.$")
	public void the_user_must_validate_the_title_should_be_Infoway_Tech_India() throws Throwable {
		 Assert.assertEquals("Employee Registration Page",driver.getTitle());
	}

	@When("^Submit button is clicked without entering any value$")
	public void submit_button_is_clicked_without_entering_any_value() throws Throwable {
	    login.clickSubmit();
	}

	@Then("^alert box should be displayed as 'Please fill in the 'Your Employee Name' box\\.'$")
	public void alert_box_should_be_displayed_as_Please_fill_in_the_Your_Employee_Name_box() throws Throwable {
		 Assert.assertEquals("Please fill in the 'Your Employee Name' box.",driver.switchTo().alert().getText());
		 driver.switchTo().alert().accept();
	}

	@When("^Submit button is clicked without entering any Employee Number$")
	public void submit_button_is_clicked_without_entering_any_Employee_Number() throws Throwable {
	    login.Id();
	    login.clickSubmit();
	}

	@Then("^alert box should be displayed as 'Enter Employee Number'$")
	public void alert_box_should_be_displayed_as_Enter_Employee_Number() throws Throwable {
		Assert.assertEquals("Enter Employee Number",driver.switchTo().alert().getText());
		 driver.switchTo().alert().accept();
	}

	@When("^user enters any character in Employee Number$")
	public void user_enters_any_character_in_Employee_Number() throws Throwable {
	   
	}

	@Then("^alert box should be displayed as 'Enter Number'$")
	public void alert_box_should_be_displayed_as_Enter_Number() throws Throwable {
	   
	}

	@When("^user enter any character in a Contact Number$")
	public void user_enter_any_character_in_a_Contact_Number() throws Throwable {
	  
	}

	@Then("^alert box should  display 'Enter Number'$")
	public void alert_box_should_display_Enter_Number() throws Throwable {
	 
	}

	@When("^Submit button is clicked without selecting any Job Location$")
	public void submit_button_is_clicked_without_selecting_any_Job_Location() throws Throwable {
	   
	}

	@Then("^alert box should be displayed as 'Select your Job Location'$")
	public void alert_box_should_be_displayed_as_Select_your_Job_Location() throws Throwable {
	    
	}

	@When("^user clicks submit button on entering wrong email pattern$")
	public void user_clicks_submit_button_on_entering_wrong_email_pattern() throws Throwable {
	  
	}

	@Then("^alert box should be displayed as 'You have entered an invalid email address!'$")
	public void alert_box_should_be_displayed_as_You_have_entered_an_invalid_email_address() throws Throwable {
	   
	}

	@When("^user clicks submit button$")
	public void user_clicks_submit_button() throws Throwable {
	   
	}

	@Then("^new page should be displayeed with the message 'Registered Successfully!'$")
	public void new_page_should_be_displayeed_with_the_message_Registered_Successfully() throws Throwable {
	   
	}


}
