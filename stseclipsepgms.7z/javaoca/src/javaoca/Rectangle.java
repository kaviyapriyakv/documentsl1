package javaoca;

import java.util.Arrays;
import java.util.List;
import java.util.TreeSet;

class Rectangle {
	public static void main(String[] args) {
		String[] a= {"one","two","three","four","five"};
		List<String> l=Arrays.asList(a);
		TreeSet<String> u=new TreeSet<String>(l);
		System.out.println(u);
	}
 
}
/*//abstract public class Rectangle {
//	abstract  void addRectangle();
//	
//
//}
//class ConsRect extends Rectangle{
//	public void  addRectangle() {
//		
//	}
//	
//}public static void main(String[] args) {
		  Set h =new HashSet();
		  h.add(1);
		  h.add("null");
		  h.add("null");
		  h.add(1);
		  System.out.println(h);
	  }
	*/