package javaoca;
 public class X {
	 
	 public static void main(String[] args) {
		 int i=0;
		 short s=0;
		 for(int j=0,k=0;j<3;j++) ;
		 for(int j=0;j<3;counter(j)); 
		 for(int j=0,int k=0;j<3;j++);
		 for(;i<5;counter(5),j++);
	 }

	private static Object counter(int i) {
		// TODO Auto-generated method stub
		return null;
	}
	 
	 
 }
//	 public static void main(String[] args) {
//		 Chrome x=new Chrome();
//			Y y= new Chrome();
//			Y y1=new Y();
//			
//		}
// }
//	
//	 class Y extends Chrome{
//			void do2() {
//				
//		}	}
//	 class Chrome{
//		 void do1() {
//				
//		 }
//	}
	
	
	
	
	
	
	

//	private final void flippr() {
//		System.out.println("Clidder");
//	}
//}
// public class Cliddet extends Clidder{
//	 public final void flippr() {
//		 System.out.println("Cliddet");
//		}
//	 public static void main(String[] args) {
//		 new Clidder().flippr();
//	 }
//}