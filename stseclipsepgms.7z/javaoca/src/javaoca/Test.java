package javaoca;
import java.util.ArrayList;
import java.util.List;
import java.util.TreeSet;
import java.util.Collections;
import java.util.function.Consumer;
public class Test {
	public static void main(String[] args) {
		try {
			if(args.length==0) throw new Exception();
		}
		catch(Exception e) {
			System.out.println("done");
			doStuff();
		}finally {
			System.out.println("finally");
		}
		}

	private static void doStuff() {
		// TODO Auto-generated method stub
		
	}
	}

/*String n=new String("arvind");
int p=n.replace('a','*').substring(2,4).indexOf("i");
System.out.println(p);
 List<String> list=new ArrayList<>();
		       list.add("hello");
		        list.add("world");
		        Consumer<List<String>>consumer=Collections::reverse;
		        consumer.accept(list);
		        System.out.println(list);*/