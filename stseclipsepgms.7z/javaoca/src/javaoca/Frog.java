package javaoca;

  interface Frog {
	static int getCtoF(int cTemp) {
		return (cTemp * 9/5)+ 32;
	}
	default String hop() {
		return "hopping";
	}
	//public void twiddle(String s);

}
