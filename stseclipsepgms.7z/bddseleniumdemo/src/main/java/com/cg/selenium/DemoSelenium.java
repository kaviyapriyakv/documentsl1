package com.cg.selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class DemoSelenium {
	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver","C:\\Users\\KPRIYAKV\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.navigate().to("http://www.google.com");
		//WebDriver driver1=new ChromeDriver();
		//driver1.get("http://www.amazon.in");
		//String s=driver.getTitle();
		//System.out.println(s);
		//driver.close();
		//driver.quit();
		//String s1=driver.getPageSource();
		//System.out.println(s1);
	
		//WebElement searchelement=driver.findElement(By.name("q"));
		/*WebElement searchelement=driver.findElement(By.linkText("Images"));
		Images.click();*/
		/*searchelement.sendKeys("apple");
		searchelement.submit();
		if(driver.getTitle().equalsIgnoreCase("apple-goggle search")) {
			System.out.println("correct page");
		}else {
			System.out.println("Incorrect");
			
		}*/
		//WebElement searchelement=driver.findElement(By.linkText("Images"));
		//searchelement.click();
		WebElement searchelement=driver.findElement(By.xpath("//*[@id=\"tsf\"]/div[2]/div[1]/div[1]/div/div[2]/input"));
		searchelement.sendKeys("capgemini");
		searchelement.submit();
		driver.navigate().back();
		//driver.navigate().forward();
		driver.navigate().refresh();
	//WebElement TxtBoxContent = driver.findElement(By.id(�WebelementID�));
	searchelement.getText();

	}
}
