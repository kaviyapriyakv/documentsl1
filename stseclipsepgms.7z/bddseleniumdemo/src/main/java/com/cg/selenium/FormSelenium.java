package com.cg.selenium;

import java.util.Iterator;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class FormSelenium {
	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver","C:\\Users\\KPRIYAKV\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		 
		//driver.get("http://www.google.com");
		driver.get("file:///C:/Users/KPRIYAKV/Documents/bddtestform.html");
		WebElement searchelement=driver.findElement(By.name("username"));
		searchelement.sendKeys("kaviya@gmail.com");		
		driver.switchTo().alert().getText();	
		String s=driver.getTitle();
		System.out.println(s);
		searchelement = driver.findElement(By.name("firstName"));
		searchelement.sendKeys("kaviya");
		

		/*List<WebElement> l=driver.findElements(By.name("lang"));
		Iterator<WebElement> i=l.iterator();
		while(i.hasNext()) {
			WebElement element =i.next();
			String value=element.getAttribute("value");
			if(value.equalsIgnoreCase("tamil") || value.equalsIgnoreCase("english")) {
				element.click();
			}
			
			List<WebElement> list=driver.findElements(By.name("radio"));
			Iterator<WebElement> j=list.iterator();
			while(i.hasNext()) {
				WebElement welement =j.next();
				String value1=welement.getAttribute("value");
				if(value1.equalsIgnoreCase("male")) {
					welement.click();
				}	
			*/
		}
		
		
		
}
