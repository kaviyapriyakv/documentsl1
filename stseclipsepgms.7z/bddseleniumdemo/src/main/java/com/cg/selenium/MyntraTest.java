package com.cg.selenium;

import java.util.List;

import javax.swing.text.html.HTMLDocument.Iterator;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;

public class MyntraTest {
	
	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver","C:\\Users\\KPRIYAKV\\chromedriver_win32\\chromedriver.exe");
		ChromeOptions options =new ChromeOptions();
		options.addArguments("--disable-notifications");
		
		WebDriver driver=new ChromeDriver(options);
		driver.get("http://www.myntra.com");
		driver.manage().window().maximize();
		Actions action=new Actions(driver);
		WebElement mensection =driver.findElement(By.xpath("/html/body/div[1]/div/div/header/div[2]/nav/div/div[1]/div/a"));
     action.moveToElement(mensection).build().perform();
    driver.findElement(By.xpath("//*[@id=\'desktop-header-cnt\']/div[2]/nav/div/div[1]/div/div/div/div/li[5]/ul/li[14]/a")).click();
    if(driver.getTitle().equalsIgnoreCase("Mens Bags & Backpacks - Buy Bags & Backpacks for Men Online")) {
    	 System.out.println("Correct page");
     }else {
    	 System.out.println("INCorrect page");
     }
    
}
}