package com.cg.selenium;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class SeleniumTest {
	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver","C:\\Users\\KPRIYAKV\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		//driver.get("file:///C:/Users/KPRIYAKV/Documents/bddtestform.html");
		//driver.get("http://www.google.com");
		driver.get("http://www.amazon.in");
		JavascriptExecutor js = (JavascriptExecutor)driver;
		js.executeScript("alert('hello world');");
        js.executeScript("window.scrollBy(0,50)");
		
}
}