package com.cg.selenium;

import java.util.Iterator;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class FindSeledemo {
	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver","C:\\Users\\KPRIYAKV\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		//driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		//driver.get("http://www.google.com");
		driver.get("http://newtours.demoaut.com");
		WebElement searchelement=driver.findElement(By.linkText("REGISTER"));
		//ExpectedConditions.
		searchelement.click();
		//WebElement searche=driver.findElement(By.tagName("a"));
		//List<WebElement> list=driver.findElements(By.tagName("a"));
		//Iterator<WebElement> i=list.iterator();
		/*while(i.hasNext()) {
			System.out.println(i.next().getText());
		}*/
		//while(i.hasNext()) {
		//	System.out.println(i.next().getAttribute("value"));
		//}
		
}}
