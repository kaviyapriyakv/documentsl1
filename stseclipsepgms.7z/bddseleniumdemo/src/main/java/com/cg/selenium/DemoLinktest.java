package com.cg.selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class DemoLinktest {
	public static void main(String[] args){
		System.setProperty("webdriver.chrome.driver","C:\\Users\\KPRIYAKV\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		//driver.get("http://www.google.com");
		driver.get("http://newtours.demoaut.com");
		WebElement searchelement=driver.findElement(By.linkText("REGISTER"));
		searchelement.click();
		String s=driver.getTitle();
		System.out.println(s);
		searchelement=driver.findElement(By.name("firstName"));
		searchelement.sendKeys("kaviya");
		 searchelement=driver.findElement(By.name("lastName"));
		searchelement.sendKeys("priya");
		 searchelement=driver.findElement(By.name("phone"));
		searchelement.sendKeys("237838909");
		searchelement=driver.findElement(By.xpath("//*[@id=\"userName\"]"));
		searchelement.sendKeys("abc@gmail.com");
		
		searchelement=driver.findElement(By.xpath("/html/body/div/table/tbody/tr/td[2]/table/tbody/tr[4]/td/table/tbody/tr/td[2]/table/tbody/tr[5]/td/form/table/tbody/tr[12]/td[2]/select"));
		Select sel=new Select(searchelement);
		sel.selectByVisibleText("INDIA");
		
		searchelement=driver.findElement(By.name("email"));
		searchelement.sendKeys("abc@gmail.com");
		searchelement=driver.findElement(By.name("password"));
		searchelement.sendKeys("abcwertf");
		searchelement=driver.findElement(By.name("confirmPassword"));
		searchelement.sendKeys("abcwertf");
		searchelement.submit();
		
		
			
}
}