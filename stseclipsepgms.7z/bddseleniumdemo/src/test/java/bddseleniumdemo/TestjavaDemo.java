package bddseleniumdemo;

import org.testng.annotations.*;

public class TestjavaDemo {
	@BeforeSuite
	public void init() {
		System.out.println(" before");
	}
   @BeforeTest
   public void beforeTest() {
	   System.out.println("before test");
   }
   @BeforeMethod
   public void beforeMethod() {
	   System.out.println("before method");
   }
   @Test
   public void testa() {
	   System.out.println("test a");
   }
   @Test
   public void testb() {
	   System.out.println("test b");
   }
   
   
   
   
   
   
   
}
