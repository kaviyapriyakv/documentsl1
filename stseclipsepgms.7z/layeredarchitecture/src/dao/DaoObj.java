package dao;

import java.util.HashSet;

import pojo.Employe;
public class DaoObj {
public void addEmployeeToDao(Employe emp) {
	 HashSet<Employe> hs=new HashSet<Employe>();
	
	
}
	
	
	
}
