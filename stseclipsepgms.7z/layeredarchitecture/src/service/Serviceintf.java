package service;

public class Serviceintf {

}
