package com.cg.model;

import java.util.Scanner;

public class Employee {
	

	private	int empid;
	private String empname;

public Employee()
{
	empid=empid;
	empname=empname;
	Scanner Scan=new Scanner(System.in);
	int empid=Scan.nextInt();
	Scanner Sc=new Scanner(System.in);
	String empname=Sc.next();
	
	
}}


