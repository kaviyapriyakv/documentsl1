package com.cg.service;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import com.cg.model.Employee;

public class EmployeeController implements EmployeeInterface {
	public void insertEmployee() {
		Employee emp=new Employee();
		emp.setEmpid(101);
		emp.setEmpname("raji");
		List empList=new ArrayList();
			empList.add(emp);/
			System.out.println(empList);
			viewEmployee(emp);
	}
	 public void viewEmployee(Employee e) {
		 System.out.println(e.getEmpid()+ ""+e.getEmpname()); 
		 
		 
	 }

	

	

}
