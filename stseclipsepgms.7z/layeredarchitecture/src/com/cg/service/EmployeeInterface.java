package com.cg.service;

import com.cg.model.Employee;

public  interface EmployeeInterface {
 
public void viewEmployee();
public void insertEmployee();

}
