package com.cg.view;

import java.util.Scanner;

import com.cg.service.EmployeeController;

public class MainEmp {
	public static void main(String []args) {
		
		EmployeeController e=new EmployeeController();
	Scanner s=new Scanner(System.in);
	int i=s.nextInt();
	switch(i) {
	case 1:e.insertEmployee();
	         break;
	case 2:  e.viewEmployee();       
		     break;
	default:
	        break;
	}
	
	}

	
	

}
