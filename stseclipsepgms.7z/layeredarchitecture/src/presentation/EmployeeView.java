package presentation;

import java.util.Scanner;

import pojo.Employe;

public class EmployeeView {
	public static void main(String []args) {
		Scanner Scan=new Scanner(System.in);
		int empid=Scan.nextInt();
		Scanner Sc=new Scanner(System.in);
		String empname=Sc.next();
		Scanner Sca=new Scanner(System.in);
		double salary=Sca.nextDouble();
		
		Employe e1=new Employe( empid, empname, salary);
		
		
		
		
	}

}
