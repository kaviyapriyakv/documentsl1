
/*class PassByValueTest {
	
	int v;
	public void calling() {
		v=5;
		System.out.println(v);
		called(v);
		System.out.println(v);
	}
public void called(int v) {
	v=25;
	v++;
	System.out.println(v);
}}
public class PassByValue{
	public static void main(String[] args) {
		PassByValueTest p=new PassByValueTest();
		p.calling();
	}
}*/

class PassByRefTest {
	
	int v;
	public void calling() {
		PassByRefTest p=new PassByRefTest();
		p.v=5;
		System.out.println(p.v);
		called(p);
		System.out.println(p.v);
	}
public void called(PassByRefTest p1) {
	p1.v=25;
	p1.v++;
	System.out.println(p1.v);
}}
public class PassByRef{
	public static void main(String[] args) {
		PassByRefTest p=new PassByRefTest();
		p.calling();
	}
}