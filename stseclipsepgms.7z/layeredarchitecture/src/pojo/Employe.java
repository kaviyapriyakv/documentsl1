package pojo;

public class Employe {
private	int employeeid;
	private String employeename;
	private double employeesalary;
public Employe() {
	
}public Employe(int empid,String empname,double salary)
{
	employeeid=empid;
	employeename=empname;
	e
}
	

}
