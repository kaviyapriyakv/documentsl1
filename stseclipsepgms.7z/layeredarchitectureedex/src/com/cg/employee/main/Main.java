package com.cg.employee.main;

import java.util.Scanner;

import com.cg.employee.model.Employee;
import com.cg.employee.service.Controller;
public class Main {
	
	    public static void main(String[] ar)  {
	
	  Controller slc=new Controller();
	    Scanner s=new Scanner(System.in);
	    System.out.println("Enter Employee Details:");
	    System.out.print("Enter id:");
	    int id=s.nextInt();
	    System.out.print("Enter name:");
	    String name=s.next();
	    System.out.print("Enter Employee salary:");
	    int salary=s.nextInt();
	    System.out.print("Enter Employee designation:");
	    String design=s.next();
	    
	    
	    Employee e=new Employee(id,name,salary,design);
	    slc.storeEmployee(e);
	    Employee e1=slc.returnToPl();
	    System.out.println(e);
	    slc.storeInsurance(e);
	    String s3=slc.returnInsurancetoPl();
	    System.out.println("Insurance Scheme is "+s3);

	 
	 

	}
	}


