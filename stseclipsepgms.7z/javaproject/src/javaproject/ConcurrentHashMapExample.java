package javaproject;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;


public class ConcurrentHashMapExample {
public static void main(String[] args) {
	Map<String,String> myMap=new ConcurrentHashMap<String,String>();
	myMap.put("1", "l");
	myMap.put("2", "l");
	myMap.put("3", "l");
	myMap.put("3", "l");
	myMap.put("4", "l");
	myMap.put("6", "l");
	System.out.println("ConcurrentHashMap before iterator"+myMap);
	Iterator<String> it=myMap.keySet().iterator();
	
	while(it.hasNext()) {
		String key=it.next();
	if(key.equals("3")) {
		myMap.put(key+"new","new3");
	}myMap.put(key, "new3");
	}	
	
System.out.println("concurrent after iterator"+ myMap);
	
Map<String,String> map=new HashMap<String,String>();
myMap.put("1", "l");
myMap.put("2", "l");
myMap.put("3", "l");
myMap.put("3", "l");
myMap.put("4", "l");
myMap.put("6", "l");
System.out.println("hashmap before iterator"+myMap);
Iterator<String> it1=myMap.keySet().iterator();

while(it1.hasNext()) {
	String key1=it1.next();
if(key1.equals("3")) {
	map.put(key1+"new","new3");
	
	
}
map.put(key1, "new3");
}
System.out.println("hashmap after iterator"+ myMap);



}
}
