package javaproject;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
interface ConsumerImp1{
	public void accept(User u);
	//list.forEach(u->System.out.println(u));
}
public class MainLambda {
public static void main(String args[]) {
	
	User u1=new User(11,"rishi","rishi@gmail.com");
	User u2=new User(12,"deeps","deeps@gmail.com");
	User u3=new User(13,"navin","navin@gmail.com");
	List<User> list=new ArrayList();
	list.add(u1);
	list.add(u2);
	list.add(u3);
	//Iterator<User> t=list.iterator();
	//list.forEach(li->System.out.println(li));//printing list using lambda
	//list.forEach(System.out::println);//printing list method reference
	list.forEach(u->System.out.println(u));//another method for printing
	/*while(t.hasNext()) {
		System.out.println(t.next());
	}*/
	//System.out.println(list);	
}}
	/*System.out.println("anonymous inner class");
	System.out.println("lambda ");
	Runnable r2=new Runnable() {
		public void run() {
			Task t3=new Task();
			t3.print();
		}
	};
	
	//MyTaskThread v=new MyTaskThread();
	//Runnable v=new MyTaskThread();//polymorphic object                                                                                                                           
	//Thread t=new Thread(v);	
	Thread t4=new Thread(r2);
	t4.start();


Runnable r5=()->{
	Task t3=new Task();
	t3.print();
};
Thread t5=new Thread(r5);
t5.start();
}}
	Thread t6=new Thread(
			()-> {
		Task t1=new Task();
		t1.print();
	});
	t6.start();
}}
	
	
	
	new Thread(
			()-> {
		Task t1=new Task();
		t1.print();
	}).start();
}}
	//we can do like this also
class human
{
	void print();
	Human h=new Human();                                            
	h.print();  //is same as
	new Human().print();
}
	
	
	new Thread(()->new Task().print()).start();
	
	new Thread(new Task()::print).start();//method reference
}}
*/