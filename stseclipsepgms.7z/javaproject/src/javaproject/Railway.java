package javaproject;

/*class timing{
	 static String timeConversion(String s)
	   {
	    String s1[]=s.split(":");
	    char c[]=s1[2].toCharArray();
	    if(s1[2].contains("PM"))
	    {
	        int n=Integer.parseInt(s1[0]);
	        n=n+12;
	        return n+":"+s1[1]+":"+c[0]+c[1];
	    }
	    else {
	    return s1[0]+"HM"+s1[1]+"MM"+c[0]+c[1];
	     }}}*/
	 public class Railway {
		 String s="18:10:45";
	        String[] s1=s.split(":");
	        int milipmHrs=0;
	    public static void main(String[] args) {
	 
	    	String s="08:10:45";
	        String[] s1=s.split(":");
	        int milipmHrs=0;
	        char[] arr=s1[2].toCharArray();
	        boolean isFound=s1[2].contains("PM");
	        if(isFound == true){
	            int pmHrs=Integer.parseInt(s1[0]);
	            milipmHrs=pmHrs-12;
	            System.out.println(milipmHrs+":"+s1[1]+":"+arr[0]+arr[1]);
	        }
	        else{

	        	 System.out.println(s1[0]+"H"+s1[1]+"M"+arr[0]+arr[1]+"S");
	        }
	    
	    }}
