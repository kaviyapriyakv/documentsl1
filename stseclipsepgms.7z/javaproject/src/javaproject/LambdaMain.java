
package javaproject;
import java.lang.Math;


interface FuncInter{
	double power(int x,int y) ;
	
}



public class LambdaMain {
public static void main(String[] args) {
	
	
	FuncInter f=(i,j)->Math.pow(i, j);
	System.out.println(f.power(2, 5));
	
	
}
	

}
