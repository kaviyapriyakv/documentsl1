package javaproject;

import javapract.FuncInter;

interface FuncInter
{
	public boolean display(String un,String pw);
		
}
public class UserNamePassWord {
public static void main(String[] args) {
	FuncInter f=(i,j)->;
	