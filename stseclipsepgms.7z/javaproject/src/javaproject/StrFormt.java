package javaproject;

public class StrFormt {
	
	

	  
}