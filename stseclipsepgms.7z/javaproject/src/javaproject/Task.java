package javaproject;

public class Task {
	public void print() {
		System.out.println("Printing...");
	}
}
