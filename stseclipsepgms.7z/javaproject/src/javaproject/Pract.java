package javaproject;
class JavaBlockExample{
	static int num;
	static String str;
	int num2;
	String str2;
	static {
		System.out.println("static block1");
		num=68;
		str="block1";
	}
	static {
		System.out.println("static block2");
		num=98;
		str="block2";
	}
	{
		System.out.println("non static block1");
		num2=10;
		str2="mystr2 from non static block1";
		System.out.println(num2);
		System.out.println(str2);
	}
	
	
	{
		System.out.println("non static block2");
		num2=20;
		str2="mystr2 from non static block2";
		System.out.println(num2);
		System.out.println(str2);
	}
	
	
	
	
}


public class Pract {
	public static void main(String[] argv) {
		{
			System.out.println("**** static block**********");
			System.out.println(num);
			System.out.println(str);
			System.out.println("****non static block*************");
JavaBlockExample j=new JavaBlockExample();
			System.out.println("**** static block**********");
			System.out.println("*******after instatntiation************");
			System.out.println(j.num2);
			System.out.println(j.str2);
		
		}
		
		
		
	}
	

}
