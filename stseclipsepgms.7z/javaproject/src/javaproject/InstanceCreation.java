package javaproject;

import java.util.ArrayList;
import java.util.List;

class Instance {
	private int age;
	private String name;
	private long number;
	
	public long getNumber() {
		return number;
	}
	public void setNumber(long number) {
		this.number = number;
	}
	public  Instance(int age, String name, long number) {
		
		this.age = age;
		this.name = name;
		this.number = number;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public long getnumber() {
		return number;
	}
	public void setnumber                    (long number) {
		this.number= number;
	}

}public class InstanceCreation {
	public static void main(String[] args) {
		Instance i1=new Instance(11,"rishi",9879037929);
		Instance i2=new Instance(22,"rita",9879037786);
		Instance i3=new Instance(33,"ravi",9564779298);
		List<User> list=new ArrayList();
		list.add(i1);
		list.add(i2);
		list.add(i3);
	}
	
	
	
	
}
