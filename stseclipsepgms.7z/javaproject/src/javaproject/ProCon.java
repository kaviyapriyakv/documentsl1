package javaproject;

import java.util.concurrent.BlockingQueue;

public class ProCon implements Runnable {
private BlockingQueue<ProdCons>queue;
this.queue=q;
	@Override
	public void run() {
		// TODO Auto-generated method stub
		for(int i=0;i<50;i++) {
			ProdCons pd=new ProdCons(""+i);
			try {
				Thread.sleep(i);
				queue.put(pd);
				System.out.println("produced"+pd.getArg());
			}catch(InterruptedException e) {
				e.printStackTrace();
				}}}
				
				
				
				
				
			
		
	}
	
	


