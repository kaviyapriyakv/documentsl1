package javaproject;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

public class ProdConsMain{
	public static void main(String[] args) {
		BlockingQueue<ProdCons>queue=new ArrayBlockingQueue<>(10);
		Procon pro=new Procon(queue);
			Consumer Cons=new Consumer(queue);
		new Thread(prodCon).start();
		new Thread(Consumer).start();
	System.outprintln("pro and cons are started");
	}


