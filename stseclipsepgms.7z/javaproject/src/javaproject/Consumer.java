package javaproject;

import java.util.Queue;
import java.util.concurrent.BlockingQueue;

public class Consumer implements Runnable {
	private BlockingQueue<ProdCons>queue;
public Consumer(BlockingQueue<ProdCons>q){
	this.queue=q;
}
		@Override
		public void run() {
			// TODO Auto-generated method stub
			try {
				ProdCons pd;
				while(pd=queue.take().getArg()!="exit") {
					Thread.sleep(10);
					Queue.put(pd);
					System.out.println("consumed"+pd.getArg());
				}}catch(InterruptedException e) {
					e.printStackTrace();
					}}} 


