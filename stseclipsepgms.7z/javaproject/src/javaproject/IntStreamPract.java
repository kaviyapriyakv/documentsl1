package javaproject;

import java.util.stream.IntStream;

public class IntStreamPract {
public static void main(String[] args) {
	int[] val= {3,1,4,5,6,5,8};
	System.out.println("originalvalues:");
	IntStream.of(val).forEach(System.out::println);
	System.out.println("max value:"+IntStream.of(val).max().getAsInt());
	System.out.println("min value:"+IntStream.of(val).min().getAsInt());
	System.out.println("count :"+IntStream.of(val).count());
	System.out.println("sum:"+IntStream.of(val).sum());
	System.out.println("Average:"+IntStream.of(val).average().getAsDouble());
System.out.println(IntStream.of(val).reduce(0,(x,y)->x+y));//sum of all values another method
}
}
