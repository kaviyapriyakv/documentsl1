package javaproject;

public  class MyTaskThread implements Runnable{


	public void run() {
		Task t1=new Task();
		t1.print();
	}
	
	

}
