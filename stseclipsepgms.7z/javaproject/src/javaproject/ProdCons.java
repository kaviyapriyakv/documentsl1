package javaproject;
 public class ProdCons {



	private String arg;

	public ProdCons(String string) {
		// TODO Auto-generated constructor stub
	}

	public String getArg() {
		return this.arg=arg;
	}

	public void setArg(String arg) {
		this.arg = arg;
	}
}
