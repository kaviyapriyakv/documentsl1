package javaproject;

Factor{
	public void 
	
}

public class Factorial {
	

}
