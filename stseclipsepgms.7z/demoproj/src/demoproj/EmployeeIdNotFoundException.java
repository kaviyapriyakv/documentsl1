package demoproj;

public class EmployeeIdNotFoundException extends Exception {

	public EmployeeIdNotFoundException(String string) {
		super(string);
		// TODO Auto-generated constructor stub
	}

	
}
