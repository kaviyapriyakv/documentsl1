package demoproj;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class DemoException {
	public void testException() {
		//int a=10/0;
	FileInputStream fs;
	try {
		fs = new FileInputStream("C:\\Users\\KPRIYAKV");
	} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
		
	//System.out.println(a);
	}
public static void main(String[] args) throws IOException{
	DemoException d=new DemoException();
	d.testException();
}
	
	
}
