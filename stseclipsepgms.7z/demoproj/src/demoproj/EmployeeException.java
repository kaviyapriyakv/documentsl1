package demoproj;

import java.util.Scanner;

public class EmployeeException {

	public static void main(String args[]) {
		String[] Name=new String[] {"ram","sam","retu"};
		int[] Id = new int[] { 4, 5, 6};
		int l = Id.length;

		Scanner sc = new Scanner(System.in);
		int i = sc.nextInt();
		for (int j = 0; j < l; j++) {
			try {
				if(i== Id[j]) {
					System.out.println(Id[j]+","+Name[j]);
				
				}else  {
				
					throw new EmployeeIdNotFoundException("Entered id not found");
				}
			} catch (EmployeeIdNotFoundException e) {
				e.printStackTrace();
				System.exit(0);
			}
		}

	}
}
