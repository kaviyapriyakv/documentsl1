package java123;
import java.util.Scanner;
import java123.Participant;
public class ExceptionDemo {
		public static void main(String[] args) {
			Scanner sc=new Scanner(System.in);
			System.out.println("Enter Name");
			String name=sc.nextLine();
			System.out.println("Enter Department");
			String dept=sc.nextLine();
			System.out.println("Enter Gender");
			char gender = sc.nextLine().charAt(0);

			Participant obj = new Participant();
			obj.setName(name);
			obj.setDepartment(dept);
			obj.setGender(gender);
		
			try {
				if(gender == 'M' || gender == 'F'|| gender == 'T' || gender == 'm' || gender == 'f'|| gender == 't') {
					System.out.println(gender);
				}else {
					throw new GenderInValidException("gender is invalid");
					
				}	
			}catch(GenderInValidException e) {
				System.out.println(e);
			}
				

		}

}
