package java123;

public class GenderInValidException extends Exception {
	public GenderInValidException(String s) {
		super(s);
		
	}

}
