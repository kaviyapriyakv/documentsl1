package loginpojo;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginPage {
	@FindBy(xpath="//span[contains(text(),'Profile')]")
	WebElement profile;

public void clickProfile() {
	profile.click();
}
@FindBy(xpath="//*[@id=\'desktop-header-cnt\']/div[2]/div[2]/div/div[2]/div[2]/div[2]/div[1]/a[2]")
WebElement logIn;
public void clickLogin() {
	logIn.click();
}

@FindBy(xpath="//*[@id=\'mountRoot\']/div/div/div/form/fieldset[1]/div[1]/input")
WebElement username;
@FindBy(xpath="//*[@id=\'mountRoot\']/div/div/div/form/fieldset[1]/div[2]/input")
WebElement password;
public void userCredentials() {
	username.sendKeys("kaviya");
	password.sendKeys("kaviya1234");
}

@FindBy(xpath="//*[@id=\'mountRoot\']/div/div/div/form/fieldset[2]/button")
WebElement submit;
public void clickSubmit() {
	submit.click();
}

public LoginPage(WebDriver driver) {
	PageFactory.initElements(driver,this);
}



}
