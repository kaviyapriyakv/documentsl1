package stepdef;

import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import loginpojo.LoginPage;

public class LoginSteps {
	WebDriver driver;
	WebElement profile;
	LoginPage login;

	@Given("^user is on Myntra Login page$")
	public void user_is_on_Myntra_Login_page() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\KPRIYAKV\\chromedriver_win32\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("https://www.myntra.com");
		/*
		 * Actions action = new Actions(driver);
		 * action.moveToElement(profile).build().perform();
		 */
		login = new LoginPage(driver);
		login.clickProfile();
		
		// driver.findElement(By.xpath("//a[contains(text(),'log in')]")).click();
	}

	/*
	 * @When("^user enters \"([^\"]*)\" and \"([^\"]*)\"$") public void
	 * user_enters_and(String arg1, String arg2) {
	 * 
	 * driver.findElement(By.xpath(
	 * "//*[@id=\"mountRoot\"]/div/div/div/form/fieldset[1]/div[1]/input")).sendKeys
	 * (arg1); driver.findElement(By.xpath(
	 * "//*[@id=\'mountRoot\']/div/div/div/form/fieldset[1]/div[2]/input")).sendKeys
	 * (arg2); }
	 */
	/*
	 * @When("^user enters \"([^\"]*)\" and \"([^\"]*)\"$") public void
	 * user_enters_and(String arg1, String arg2) {
	 * 
	 * driver.findElement(By.xpath(
	 * "//*[@id=\"mountRoot\"]/div/div/div/form/fieldset[1]/div[1]/input")).sendKeys
	 * (arg1); driver.findElement(By.xpath(
	 * "//*[@id=\'mountRoot\']/div/div/div/form/fieldset[1]/div[2]/input")).sendKeys
	 * (arg2);
	 * 
	 * }
	 */
	/*@When("^user enters username and password$")
	public void user_enters_username_and_password(DataTable arg1) {
		List<List<String>> list = arg1.raw();*/
	@When("^user enters username and password$")
    public void user_enters_username_and_password() throws Throwable {
		login.userCredentials();
		// driver.findElement(By.xpath("//*[@id=\"mountRoot\"]/div/div/div/form/fieldset[1]/div[1]/input")).sendKeys(list.get(0).get(0));
		// driver.findElement(By.xpath("//*[@id=\'mountRoot\']/div/div/div/form/fieldset[1]/div[2]/input")).sendKeys(list.get(0).get(1));
		// throw new PendingException();
	}

	@When("^user clicks on submit$")
	public void user_clicks_on_submit() throws Throwable {
        login.clickSubmit();
		//driver.findElement(By.xpath("//*[@id=\'mountRoot\']/div/div/div/form/fieldset[2]/button")).click();
		// throw new PendingException();
	}

	@Then("^Home page must appear$")
	public void home_page_must_appear() throws Throwable {
		// Write code here that turns the phrase above into concrete actions

		// throw new PendingException();
	}

}
