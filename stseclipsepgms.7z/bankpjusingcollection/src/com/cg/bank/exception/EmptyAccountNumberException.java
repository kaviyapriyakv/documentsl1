package com.cg.bank.exception;

import java.util.Scanner;

public class EmptyAccountNumberException  extends RuntimeException{
	public EmptyAccountNumberException()
	{
		System.out.println("Account cannot be zero");
	}
	public EmptyAccountNumberException(String s)
	{
		System.out.println(s);
	}



}
	




