/**
 * @author KPRIYAKV
 * Date : 18/10/19
 * Description : Customer class contains all variables for banking 
 */
package com.cg.bank.model;

public class Customer {
	private int customerId;
	private String customerName;
	private int accountId;
	private String accountType;
	private float balance;
	float depositamount;
	float withdrawamount;
	int sourceAccountid;
	int recieverAccountId;

	public int getSourceAccountid() {
		return sourceAccountid;
	}

	public void setSourceAccountid(int sourceAccountid) {
		this.sourceAccountid = sourceAccountid;
	}

	public int getRecieverAccountId() {
		return recieverAccountId;
	}

	public void setRecieverAccountId(int recieverAccountId) {
		this.recieverAccountId = recieverAccountId;
	}

	float transferamount;

	public float getDepositamount() {
		return depositamount;
	}

	public void setDepositamount(float depositamount) {
		this.depositamount = depositamount;
	}

	public float getWithdrawamount() {
		return withdrawamount;
	}

	public void setWithdrawamount(float withdrawamount) {
		this.withdrawamount = withdrawamount;
	}

	public float getTransferamount() {
		return transferamount;
	}

	public void setTransferamount(float transferamount) {
		this.transferamount = transferamount;
	}

	public Customer() {
	}

	public Customer(int customerId, String customerName, int accountId, String accountType, float balance,
			float depositamount, float withdrawamount, float transferamount) {
		super();
		this.customerId = customerId;
		this.customerName = customerName;
		this.accountId = accountId;
		this.accountType = accountType;
		this.balance = balance;
		this.depositamount = depositamount;
		this.withdrawamount = withdrawamount;
		this.transferamount = transferamount;
	}

	public Customer(int Id) {
		accountId = Id;
	}

	public Customer(int Id, float amount) {
		accountId = Id;
		depositamount = amount;

	}

	public Customer(float amount, int Id0) {
		withdrawamount = amount;
		accountId = Id0;
	}

	public Customer(int Id1, int Id2, float amount) {
		sourceAccountid = Id1;
		recieverAccountId = Id2;
		transferamount = amount;
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public int getAccountId() {
		return accountId;
	}

	public void setAccountId(int accountId) {
		this.accountId = accountId;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public float getBalance() {
		return balance;
	}

	public void setBalance(float balance) {
		this.balance = balance;
	}

	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", customerName=" + customerName + ", accountId=" + accountId
				+ ", accountType=" + accountType + ", balance=" + balance  + "]";
	}

}
