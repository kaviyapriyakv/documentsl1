/**
 * @author KPRIYAKV
 * Date : 18/10/19
 * Description : declaration for DaoC class
 */
package com.cg.bank.dao;

import java.util.HashMap;
import com.cg.bank.model.Customer;

public interface DaoI {
	public void createCustomer(Customer customer);

	public HashMap<Integer, Customer> hashMap();

	public void print(int id);

}
