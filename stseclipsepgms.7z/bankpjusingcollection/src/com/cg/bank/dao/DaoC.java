/**
 * @author KPRIYAKV
 * Date : 18/10/19
 * Description : getting details of customer using HashMap
 */
package com.cg.bank.dao;

import java.util.HashMap;

import com.cg.bank.dao.DaoI;
import com.cg.bank.model.Customer;

public class DaoC implements DaoI {
	Customer customer;
	HashMap<Integer, Customer> hash = new HashMap<Integer, Customer>();

	public void createCustomer(Customer customer) {
		this.customer = customer;
		hash.put(customer.getAccountId(), customer);

	}

	public void print(int Id) {
		System.out.println(hash.get(Id));

	}

	public HashMap<Integer, Customer> hashMap() {

		return hash;
	}
}
