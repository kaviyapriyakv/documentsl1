/**
 * @author KPRIYAKV
 * Date : 18/10/19
 * Description : Getting choice from user to access the account
 */
package com.cg.bank.view;

import java.util.Scanner;
import com.cg.bank.service.CustomerI;
import com.cg.bank.model.Customer;
import com.cg.bank.service.CustomerController;

public class MainBanking {

	public static void main(String[] args) {
		CustomerI customer1 = new CustomerController();
		Customer customer;
		int choice = 0;
		do {System.out.println("WELCOME TO XYZ BANK");
			System.out.println("Enter your choice for further access :");
			System.out.println("1. Create Details");
			System.out.println("2. Deposit Amount");
			System.out.println("3. Withdraw Amount");
			System.out.println("4. Transfer Amount");
			System.out.println("5. view mainbalance");
			Scanner scanner = new Scanner(System.in);
			choice = scanner.nextInt();

			switch (choice) {
			case 1:
				customer1.addCustomer();
				break;
			case 2:
				System.out.println("enter the id");
				int id = scanner.nextInt();
				System.out.println("enter the amount");
				float amount = scanner.nextInt();
				customer = new Customer(id, amount);
				customer1.deposit(customer);
				break;
			case 3:
				System.out.println("enter the id");
				int id1 = scanner.nextInt();
				System.out.println("enter the amount");
				float amount1 = scanner.nextInt();
				customer = new Customer(amount1, id1);
				customer1.withdraw(customer);
				break;
			case 4:
				System.out.println("enter your account number to transfer");
				int id2 = scanner.nextInt();
				System.out.println("enter the amount");
				float amount2 = scanner.nextInt();
				System.out.println("enter the account number to transfer your money");
				int id3 = scanner.nextInt();
				customer = new Customer(id2, id3, amount2);
				customer1.transfer(customer);
				
				break;

			case 5:
				System.out.println("enter id: ");
				int id4 = scanner.nextInt();
				customer1.viewMainBalance(id4);
				break;

			}
		} while (choice != 0);
	}
}
