/**
 * @author KPRIYAKV
 * Date : 18/10/19
 * Description : creating method for deposit amount, withdraw amount
 * ,transfer amount and view balance
 */
package com.cg.bank.service;

import java.util.Scanner;
import com.cg.bank.dao.DaoC;
import com.cg.bank.dao.DaoI;
import com.cg.bank.exception.EmptyAccountNumberException;
import com.cg.bank.model.Customer;
import com.cg.bank.service.CustomerI;

public class CustomerController implements CustomerI {
	DaoC dao = new DaoC();
	Scanner scanner2 = new Scanner(System.in);
	Customer customer;

	public void addCustomer() {

		System.out.println("enter customer id:");
		int customerId = scanner2.nextInt();
		System.out.println("enter customer name");
		String customerName = scanner2.next();
		System.out.println("enter account id:");
		int accountId = scanner2.nextInt();

		try {
			if (accountId == 0) {
				throw new EmptyAccountNumberException();
			}
		} catch (EmptyAccountNumberException exception) {
			System.err.println(exception);
			System.exit(0);
		}
		System.out.println("enter account type");
		String accountType = scanner2.next();
		System.out.println("enter the initial balance :");
		float balance = scanner2.nextFloat();
		System.out.println("customer created");
		customer = new Customer(customerId, customerName, accountId, accountType, balance, balance, balance, balance);
		dao.createCustomer(customer);
		System.out.println("Customer added");

	}

	public void deposit(Customer c) {
		if (dao.hashMap().isEmpty()) {
			System.out.println("invalid");
		} else {
			if (dao.hashMap().containsKey(c.getAccountId())) {
				float deposit1 = dao.hashMap().get(c.getAccountId()).getBalance() + c.getDepositamount();
				dao.hashMap().get(c.getAccountId()).setBalance(deposit1);
				System.out.println("deposited");
				System.out.println("balance of " + dao.hashMap().get(c.getAccountId()).getAccountId() + " is "
						+ dao.hashMap().get(c.getAccountId()).getBalance());
			} else {
				System.out.println("Deposit failed");
			}
		}
	}

	public void withdraw(Customer c) {
		if (dao.hashMap().isEmpty()) {
			System.out.println("invalid");
		} else {
			if (dao.hashMap().containsKey(c.getAccountId())) {
				if (dao.hashMap().get(c.getAccountId()).getBalance() > c.getWithdrawamount()) {
					float withdraw1 = dao.hashMap().get(c.getAccountId()).getBalance() - c.getWithdrawamount();
					dao.hashMap().get(c.getAccountId()).setBalance(withdraw1);
					System.out.println("withdrawed");
					System.out.println("balance is " + dao.hashMap().get(c.getAccountId()).getBalance());
				}
			} else {
				System.out.println("Withdraw failed");
			}
		}
	}

	public void viewMainBalance(int Id) {

		System.out.println("enter account id");
		dao.print(Id);
		// System.out.println(dao.hashMap().get(Id).getBalance());
	}

	public void transfer(Customer c) {

		if (dao.hashMap().isEmpty()) {
			System.out.println("invalid");
		} else {
			if (dao.hashMap().containsKey(c.getSourceAccountid())) {
				if (dao.hashMap().containsKey(c.getRecieverAccountId())) {
					if (dao.hashMap().get(c.getSourceAccountid()).getBalance() > dao.hashMap()
							.get(c.getRecieverAccountId()).getBalance()) {
						float transferS = dao.hashMap().get(c.getSourceAccountid()).getBalance()
								- (c.getTransferamount());
						dao.hashMap().get(c.getSourceAccountid()).setBalance(transferS);
						float transferR = dao.hashMap().get(c.getRecieverAccountId()).getBalance()
								+ c.getTransferamount();
						dao.hashMap().get(c.getRecieverAccountId()).setBalance(transferR);
						System.out.println("transferred");
						System.out.println("your balance of account" + dao.hashMap().get(c.getSourceAccountid()) + "is"
								+ dao.hashMap().get(c.getSourceAccountid()).getBalance());
						// System.out.println("send " +
						// dao.hashMap().get(c.getAccountId()).setBalance(transferS));
					}
				}
			} else {
				System.out.println("Transfer failed");
			}
		}
	}
}
