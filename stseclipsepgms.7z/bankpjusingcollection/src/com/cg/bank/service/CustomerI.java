
/**
 * @author KPRIYAKV
 * Date : 18/10/19
 * Description : Declaration for CustomerController class
 */
package com.cg.bank.service;

import com.cg.bank.model.Customer;

public interface CustomerI {
	public void deposit(Customer customer1);

	public void withdraw(Customer customer1);

	public void addCustomer();

	public void viewMainBalance(int id4);

	public void transfer(Customer customer);

}
