package com.cg.seleniumtestng;

import org.testng.annotations.Test;

public class TestngTest {
	@Test(invocationCount=3)
	public void a() {
		
		System.out.println("a");
	}
	@Test(expectedExceptions=ArithmeticException.class)
public void b() {
		int b=10/0;
	System.out.println(b);
	}
	@Test(priority=3,dependsOnMethods="c")
public void c() {
	System.out.println("c");
}


}
