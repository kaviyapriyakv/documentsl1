package com.cg.seleniumtestng;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
public class TestngDemo {
    WebDriver driver;
    Actions action;
    WebElement profile,login;
@BeforeSuite
public void init()
{
	System.setProperty("webdriver.chrome.driver", "C:\\Users\\KPRIYAKV\\chromedriver_win32\\chromedriver.exe");  
	driver=new ChromeDriver();
    driver.manage().window().maximize();
    driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
}
@BeforeTest
public void launchPage()
{
    driver.get("https://www.myntra.com");
}
@BeforeMethod
public void beginning()
{
    action=new Actions(driver);
    profile=driver.findElement(By.xpath("//span[contains(text(),'Profile')]"));
    action.moveToElement(profile).build().perform();
}
public void login()
{
    profile=driver.findElement(By.xpath("//a[contains(text(),'log in')]"));
    profile.click();
}
  
@Test
public void login1()
{
        login();
        profile=driver.findElement(By.xpath("//input[@placeholder='Your Email Address']"));
        profile.sendKeys("kirthika@gmail.com");
        profile=driver.findElement(By.xpath("//input[@placeholder='Enter Password']"));
        profile.sendKeys(" ");
        profile.submit();
       
}
@Test
public void login2()
{
        login();
        profile=driver.findElement(By.xpath("//input[@placeholder='Your Email Address']"));
        profile.sendKeys("");        
        profile=driver.findElement(By.xpath("//input[@placeholder='Enter Password']"));
        profile.sendKeys("*kaviya");
        profile.submit();
     
}
@Test
public void login3()
{
        login();
        profile=driver.findElement(By.xpath("//input[@placeholder='Your Email Address']"));
        profile.sendKeys("");
        
        profile=driver.findElement(By.xpath("//input[@placeholder='Enter Password']"));
        profile.sendKeys("");
        profile.submit();
       
}
@Test
public void login4()
{
        login();
        profile=driver.findElement(By.xpath("//input[@placeholder='Your Email Address']"));
       profile.sendKeys("kaviyapriya41@gmail.com");
        
        profile=driver.findElement(By.xpath("//input[@placeholder='Enter Password']"));
        profile.sendKeys("K@viya6398");
        
        profile.submit();
        driver.navigate().to("https://www.myntra.com");
       // login=driver.findElement(By.xpath("//button[@class='login-login-button']"));
        //login.click();
        Assert.assertEquals(driver.getTitle(),"Online Shopping for Women, Men, Kids Fashion & Lifestyle - Myntra" );
}
@AfterSuite
public void close()
{
    driver.quit();
}

 

}
 












































/*package com.cg.seleniumtestng;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class TestngDemo {
	WebDriver driver;
	Actions action;

	@BeforeSuite
	public void init() {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\KPRIYAKV\\chromedriver_win32\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
	}

	@BeforeTest
	public void launchPage() {
		driver.get("http://www.myntra.com");
	}
	@Test
	public void testHomePage() {
		Assert.assertEquals(driver.getTitle(), "Online Shopping for Women, Men, Kids Fashion & Lifestyle - Myntra");
	}

	public void testProfile() {
		action = new Actions(driver);
		WebElement profile = driver.findElement(By.xpath("//span[contains(text(),'Profile')]"));
		action.moveToElement(profile).build().perform();
		profile = driver.findElement(By.xpath("//a[contains(text(),'log in')]"));
		profile.click();

	public void logina() {
		
	}
        
	
	

	@Test
	public void Login() {
		testProfile();
		profile = driver.findElement(By.xpath("//*[@id=\"mountRoot\"]/div/div/div/form/fieldset[1]/div[1]/input"));
		profile.sendKeys("kaviyapriya41@gmail.com");
		profile = driver.findElement(By.xpath("//*[@id=\"mountRoot\"]/div/div/div/form/fieldset[1]/div[2]/input"));
		profile.sendKeys("K@viya6398");
        profile.submit();
        
		Assert.assertEquals(driver.getTitle(), "Login");

	}

	@Test
	public void Loginfail() {
		testProfile();
		profile = driver.findElement(By.xpath("//*[@id=\"mountRoot\"]/div/div/div/form/fieldset[1]/div[1]/input"));
		profile.sendKeys("");
		profile = driver.findElement(By.xpath("//*[@id=\"mountRoot\"]/div/div/div/form/fieldset[1]/div[2]/input"));
		profile.sendKeys("");
        profile.submit();
		
		Assert.assertEquals(driver.getTitle(), "Online Shopping for Women, Men, Kids Fashion & Lifestyle - Myntra");

	}

}
	
	
	
	
*/