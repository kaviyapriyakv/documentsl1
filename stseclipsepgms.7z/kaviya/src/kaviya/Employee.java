package kaviya;

public class Employee {
	int employeeid;
	String employeeName;
	static int objectcount;
	Employee(){
		objectcount++;
		
	}
Employee(int empid)
{objectcount++;
}
Employee(int empid,String empname)
{objectcount++;
}
public static void main(String[] args)
{Employee e =new Employee(5);
Employee d =new Employee(2,"lily");

	System.out.println(objectcount, empname);
	}
}