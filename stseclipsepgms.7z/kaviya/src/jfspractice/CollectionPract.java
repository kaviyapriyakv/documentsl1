package jfspractice;

import java.util.HashSet;
import java.util.Iterator;

 class CollectionPract {
int empid;
String empname;
CollectionPract (int empid,String empname){
	this.empid=empid;
	this.empname=empname;
}
String display() {
	return"[" + empid + ","+empname+"]";
	
}

	public static void main(String[] args)
	{
		HashSet<CollectionPract> hs=new HashSet<CollectionPract >();
		CollectionPract  e= new CollectionPract (1,"kavi");
		hs.add(e);
		hs.add(new CollectionPract (2,"kirthi"));
		hs.add(new CollectionPract (3,"priya"));
		hs.add(new CollectionPract (4,"rose"));
		hs.add(new CollectionPract (5,"vaish"));
	System.out.println("enhance forloop");
	for(CollectionPract  e1:hs)
	{
		System.out.println(e1.display());
	}
	
	Iterator<CollectionPract> i=hs.iterator();
	System.out.println("iterator method");
	while(i.hasNext()) {
		CollectionPract c=i.next();
		System.out.println(c.display());
	}
	Iterator r=hs.iterator();
	System.out.println("iterator method");
	while(r.hasNext()) {
		CollectionPract c=(CollectionPract)r.next();
		System.out.println(c.display());
	}}}




