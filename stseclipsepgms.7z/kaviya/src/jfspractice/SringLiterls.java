package jfspractice;

public class SringLiterls {
	public static void main(String[] args) {

		String s="kaviya priya";
		String[] a=s.split(" ");
		for(int i=0;i<a.length();i++)
		{	
		System.out.println(a[i]);
		
		}}
	}
	


