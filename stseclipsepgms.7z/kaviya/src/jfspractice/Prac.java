package jfspractice;

public class Prac {
	//String s="08:10:45";
	
	public static void main(String[] args) {
		 
		String str ="1:10:45";
        String[] arrOfStr = str.split(":", 3); 
  int a=Integer.parseInt(arrOfStr[0]);
      //  for (String a : arrOfStr) 
        if(a>12) {
        	a=a-12;
        	System.out.print(a+"h"+arrOfStr[1]+"m"+arrOfStr[2]+"s"+"PM"); 
        }else
            System.out.print(arrOfStr[0]+"h"+arrOfStr[1]+"m"+arrOfStr[2]+"s"+"AM"); 
}

	
	}
