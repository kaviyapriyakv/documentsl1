package jfspractice;

import java.util.Calendar;
public class CalenderDemo {
	public static void main(String args[]) {
		Calender c=Calendar.getInstance();
		System.out.println("The Current Date is:" + c.getDate());
		System.out.println("The current time is:" + c.getTime());
		System.out.println("The Current calenders year is:" + c.get(Calendar.MINUTE());
		System.out.println("The Current calenders month:" + c.get(Calendar.DAY_OF_MONTH()));
		System.out.println("The Current calenders month:" + c.get(Calendar.DAY_OF_WEEK()));
		System.out.println("The Current calenders month:" + c.get(Calendar.SECOND()));
		System.out.println("The Current calenders month:" + c.get(Calendar.HOUR()));
	
	
	
	
	
	
	
	
	
	
	
	
	
	}

}
