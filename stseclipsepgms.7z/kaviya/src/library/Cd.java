package library;

public class Cd extends MediaItem {
	private String artist;
	private String genre;

	public Cd(int identificationNumber, String title, int numberOfCopies, int shelfNumber, String artist,
			String genre) {
		super(identificationNumber, title, numberOfCopies, shelfNumber);
		this.artist = artist;
		this.genre = genre;
	}

	public String getArtist() {
		return artist;
	}

	public void setArtist(String artist) {
		this.artist = artist;
	}

	public String getGenre() {
		return genre;
	}

	public void setGenre(String genre) {
		this.genre = genre;
	}

	@Override
	public String toString() {
		return "Cd [artist=" + artist + ", genre=" + genre + ", toString()=" + super.toString() + "]";
	}

	@Override
	public void display() {
		// TODO Auto-generated method stub
		Items item = new Cd(getIdentificationNumber(), getTitle(), getNumberOfCopies(), getShelfNumber(), artist,
				genre);
		System.out.println(item);

	}
}
