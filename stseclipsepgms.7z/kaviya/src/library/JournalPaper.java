package library;

public class JournalPaper extends WrittenItem {
private int yearOfPublished;

 

    public JournalPaper(int identificationNumber2, String title2, int numberOfCopies2, String author, int yearOfPublished) {
    super(identificationNumber2, title2, numberOfCopies2, author);
    this.yearOfPublished = yearOfPublished;
}

 

    public int getYearOfPublished() {
        return yearOfPublished;
    }

 

    public void setYearOfPublished(int yearOfPublished) {
        this.yearOfPublished = yearOfPublished;
    }

 

    @Override
    public String toString() {
        return "JournalPaper [yearOfPublished=" + yearOfPublished+", toString()="
                + super.toString() + "]";
    }

 

    @Override
    public void display() {
        // TODO Auto-generated method stub
        Items item=new JournalPaper(getIdentificationNumber(),getTitle(),getNumberOfCopies(),getAuthor(),yearOfPublished);
        
    }
    

 

}
 

