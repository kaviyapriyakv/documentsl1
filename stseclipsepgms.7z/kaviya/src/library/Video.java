package library;

public class Video extends MediaItem {
	private String director;
	private String genre;

	public Video(int identificationNumber, String title, int numberOfCopies, int shelfNumber, String director,
			String genre) {
		super(identificationNumber, title, numberOfCopies, shelfNumber);
		this.director = director;
		this.genre = genre;
	}

	public String getDirector() {
		return director;
	}

	public void setDirector(String director) {
		this.director = director;
	}

	public String getGenre() {
		return genre;
	}

	public void setGenre(String genre) {
		this.genre = genre;
	}

	@Override
	public String toString() {
		return "Video [director=" + director + ", genre=" + genre + ", toString()=" + super.toString() + "]";
	}

	@Override
	public void display() {
		// TODO Auto-generated method stub

	}

}
