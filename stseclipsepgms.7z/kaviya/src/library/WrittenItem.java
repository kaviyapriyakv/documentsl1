package library;

public abstract class WrittenItem extends Items {
	private String author;

	public WrittenItem(int identificationNumber2, String title2, int numberOfCopies2, String author) {
		super();
		this.author = author;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public abstract void display();

	@Override
	public String toString() {
		return "WrittenItem [author=" + this.author + ", toString()=" + super.toString() + "]";
	}

}
