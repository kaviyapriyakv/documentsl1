package library;

import java.util.Scanner;

public class Main {
	public static void main(String args[]) {
		System.out.println("Welcome");
		System.out.println("Please enter your option");
		System.out.println("1.MediaItem");
		System.out.println("2.WrittenItem");
		Scanner s = new Scanner(System.in);
		int option = s.nextInt();
		switch (option) {
		case 1:
			System.out.println("You selected MediaItem");
			System.out.println("Enter the type");
			String type = s.next();
			if (type.equalsIgnoreCase("Cd")) {
				Cd cd = new Cd(01, "Song cd", 10, 5, "singer", "melody");
				cd.display();

			} else if (type.equalsIgnoreCase("Video")) {
				Video video = new Video(02, "video cd", 15, 15, "director", "melody");
				video.display();
			} else {
				System.out.println("Enter the valid type");
			}
			break;
		case 2:
			System.out.println("You selected WrittenItem");
			System.out.println("Enter the type");
			String type1 = s.next();
			if (type1.equalsIgnoreCase("book")) {
				Books book = new Books(03, "Programming", 20, "Anitha goel");
				book.display();

			} else if (type1.equalsIgnoreCase("Journal")) {
				JournalPaper jp = new JournalPaper(04, "Journal", 25, "Journal writter", 2019);
				jp.display();
			} else {
				System.out.println("Enter the valid type");
			}
			break;
		default:
			System.out.println("Enter the valid option");
		}
	}
}
