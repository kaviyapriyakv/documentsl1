package library;

public abstract class MediaItem extends Items {
		public abstract void display();
		private int shelfNumber;

		 

		public MediaItem(int identificationNumber, String title, int numberOfCopies, int shelfNumber) {
		    super();
		    this.shelfNumber = shelfNumber;
		}

		 

		public int getShelfNumber() {
		    return shelfNumber;
		}
		public void setShelfNumber(int shelfNumber) {
		    this.shelfNumber = shelfNumber;
		}
		@Override
		public String toString() {
		    return "MediaItem [shelfNumber=" + this.shelfNumber + ", toString()="
		            + super.toString() +  "]";
		}

		 

		}

