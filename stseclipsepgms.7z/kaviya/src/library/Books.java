package library;

public class Books extends WrittenItem{
	Books(int identificationNumber,String titile, int numberOfCopies,String author)
	{
	    super(identificationNumber,titile,numberOfCopies, author);
	}
	    
	    @Override
	    public void display() {
	        // TODO Auto-generated method stub
	        Items item=new Books(getIdentificationNumber(),getTitle(),getNumberOfCopies(),getAuthor());
	        System.out.println(item);
	    }

	 

	}
	 

