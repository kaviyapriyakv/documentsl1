package com.cg.springwithjpa.service;

import java.util.List;

import com.cg.springwithjpa.entity.Transaction;

public interface BankController {
     public boolean createAccount(String name,String phoneNo, String password, long accountNo,int balance) ;
     public int viewBalance(long accountNo) ;
     public int depositAmount(long accountNo, int deposit) ;
     public int withdrawAmount(long accountNo, int withdraw) ;
     public boolean fundTransfer(long accountNo , long accno,int amount) ;
     public boolean accountValidation(long accountNo,String password) ;
 	 public List<Transaction> getTransaction(long accountNo)  ;
	public int passwordValidation(String password);
	public int checkBalance(int balance);
	int phoneNoValidation(String phoneNo);
	int nameValidation(String name);

}
	