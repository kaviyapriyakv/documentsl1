package com.cg.springwithjpa.view;
import java.util.List;
import java.util.Scanner;
import org.apache.log4j.BasicConfigurator;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.springwithjpa.entity.Transaction;
import com.cg.springwithjpa.service.BankControllerExe;

public class Client {

	public static void main(String[] args) {
		int choice, val, balance;
		String name, pwd, phoneNo;
		Scanner scanner = new Scanner(System.in);
		ApplicationContext ctx = new ClassPathXmlApplicationContext("Beans.xml");
		BankControllerExe bankService = ctx.getBean("bankService", BankControllerExe.class);
		BasicConfigurator.configure();
		
		while(true) {

			System.out.println("$$$$$$ " + "Welcome to XYZ bank!!!" + " $$$$$$");
			System.out.println("Please Selcet Your Option from below...");
			System.out.println("1.Create an Account");
			System.out.println("2.Balance Check");
			System.out.println("3.Money Deposit");
			System.out.println("4.Money Withdrawl");
			System.out.println("5.Money Transfer");
			System.out.println("6.Print Transaction statement");
			System.out.println("7.Exit");
			choice = scanner.nextInt();
			switch (choice) {
			case 1:
				System.out.println("Please fill the following to create account");
				do {
					System.out.println("Enter your name: ");
					name = scanner.next();
					val = bankService.nameValidation(name);
				} while (val != 1);
				do {
					System.out.println("Enter your mobile number: ");
					phoneNo = scanner.next();
					val = bankService.phoneNoValidation(phoneNo);
				} while (val != 1);
				int x = 100;
				long randaccno = (long) (Math.floor(Math.random() * x) + 112603461);

				do {
					System.out.println("Generate 4 digit Pin Number: ");
					pwd = scanner.next();
					val = bankService.passwordValidation(pwd);
				} while (val != 1);
				do {
					System.out.println("Enter the amount: ");
					balance = scanner.nextInt();
					val = bankService.checkBalance(balance);
				} while (val != 1);
				boolean result = bankService.createAccount(name, phoneNo, pwd, randaccno, balance);
				if (result) {
					System.out.println("Your Account has been created successfully !!! " + randaccno);
				}
				break;
			case 2:
				System.out.println("Enter the account number: ");
				randaccno = scanner.nextLong();
				System.out.println("Enter your 4 digit Pin Number");
				pwd = scanner.next();
				boolean bank1 = bankService.accountValidation(randaccno, pwd);
				if (bank1) {
					balance = bankService.viewBalance(randaccno);
					if (balance != 0) {
						System.out.println("Your  account balance is: " + balance);
					} else {
						System.out.println("Error occured:");
					}
				} else {
					System.out.println(" You have entered are invalid details..... Please Check once again..");
				}
				break;

			case 3:
				System.out.println("Enter your account number");
				randaccno = scanner.nextLong();
				System.out.println("Enter your 4 digit Pin");
				pwd = scanner.next();
				boolean bank2 = bankService.accountValidation(randaccno, pwd);
				if (bank2) {
					System.out.println("Enter the amount to be deposited");
					int deposit = scanner.nextInt();
					balance = bankService.depositAmount(randaccno, deposit);
					System.out.println("Rs. " + deposit + " is deposited to your account");
					System.out.println("your current balance is " + balance);
				} else {
					System.out.println("The details you have entered are invalid....Check once again..");
				}
				break;

			case 4:
				System.out.println("Enter your account number");
				randaccno = scanner.nextLong();
				System.out.println("Enter your 4 digit Pin");
				pwd = scanner.next();
				bank2 = bankService.accountValidation(randaccno, pwd);
				if (bank2) {
					balance = bankService.viewBalance(randaccno);
					System.out.println("Your current balance is " + balance);
					System.out.println("Enter the amount to  withdraw");
					int withdraw = scanner.nextInt();
					balance = bankService.withdrawAmount(randaccno, withdraw);
					if (balance >= 0) {
						System.out.println("Rs. " + withdraw + " has been withdrawan from your account...");

						System.out.println("Your new account balance is " + balance + "\n");
					} else {
						System.out.println("Insufficient Balance..");
					}
				}

				else {
					System.out.println("You have entered are invalid details..... Please Check once again..");
				}
				break;

			case 5:
				System.out.println("Enter the senders account number");
				randaccno = scanner.nextLong();
				System.out.println("Enter your 4 digit Pin");
				pwd = scanner.next();
				bank2 = bankService.accountValidation(randaccno, pwd);
				if (bank2) {
					System.out.println("\nEnter the receivers account transfer");
					long accno = scanner.nextLong();
					System.out.println("Enter the amount you want to transfer");
					int amount = scanner.nextInt();
					boolean transfer = bankService.fundTransfer(randaccno, accno, amount);
					if (transfer) {
						System.out.println("Rs. " + amount + " amount has been transferred successfully...");
					} else {
						System.out.println("Something went wrong during transaction...");
					}
				} else {
					System.out.println(" You have entered are invalid details....Please Check once again..");
				}
				break;

			case 6:
				System.out.println("Enter your account number");
				randaccno = scanner.nextLong();
				System.out.println("Enter your 4 digit Pin Number");
				pwd = scanner.next();
				bank2 = bankService.accountValidation(randaccno, pwd);
				if (bank2) {
					List<Transaction> trans = bankService.getTransaction(randaccno);

					System.out.println("----------Transaction Statement----------\n");

					for (Transaction tran : trans) {
						System.out.println(tran);
					}
				} else {
					System.out.println("You have entered are invalid details..... Please Check once again..");
				}
				break;

			case 7:
				System.out.println("**********Thank you for using our Bank Services***********");
				System.exit(0);
				break;

			default:
				if(choice <=0 && choice>7) {
				System.out.println("kindly select the  valid options shown below......");
				}
				break;
			}
		}

	}
}
