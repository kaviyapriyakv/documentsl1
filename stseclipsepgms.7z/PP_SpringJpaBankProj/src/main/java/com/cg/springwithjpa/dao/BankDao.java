package com.cg.springwithjpa.dao;

import java.util.List;

import com.cg.springwithjpa.entity.Bank;
import com.cg.springwithjpa.entity.Transaction;

public interface BankDao {
   boolean createAccount(Bank bank);
   int showBalance(long accountNo);
   int depositAmount(long accountNo, int deposit);
   int withdrawAmount(long accountNo, int withdraw) ;
   boolean transferAmount(long accountNo, long accno, int amount);
   boolean accountValidation(long accountNo,String password);
   public List<Transaction> getTransactions(long accountNo) ;
	


}
