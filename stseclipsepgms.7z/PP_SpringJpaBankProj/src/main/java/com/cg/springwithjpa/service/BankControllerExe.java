package com.cg.springwithjpa.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cg.springwithjpa.dao.BankDaoExe;
import com.cg.springwithjpa.entity.Bank;
import com.cg.springwithjpa.entity.Transaction;


@Service("bankService")
public class BankControllerExe implements BankController
{
	int balance;
	@Autowired
	private BankDaoExe bankDao;


	public boolean createAccount(String name, String phoneNo, String password, long accountNo, int balance) {
		
		Bank bank = new Bank();
	    bank.setName(name);
	    bank.setPhoneNo(phoneNo);
	    bank.setPassword(password);
	    bank.setAccountNo(accountNo);
	    bank.setBalance(balance);
	    
	    boolean result = bankDao.createAccount(bank);
	    return result;
	}


	public int viewBalance(long accountNo) {
	
		balance = bankDao.showBalance(accountNo);
	
		 return balance;
	}

	
	public int depositAmount(long accountNo, int deposit) {
		int balance;
	
		 balance = bankDao.depositAmount(accountNo, deposit);
		 return balance;
	}

	
	public int withdrawAmount(long accountNo, int withdraw) {
		int balance;
		
		 balance = bankDao.withdrawAmount(accountNo,withdraw);
		 return balance;
	}

	
	public boolean fundTransfer(long accountNo, long accno, int amount) {
	
		boolean fund = bankDao.transferAmount(accountNo,accno,amount);
	      return fund;
	}

	
	public boolean accountValidation(long accountNo, String password) {
	
		boolean b = bankDao.accountValidation(accountNo,password);
	    return b;
	}

	
	public List<Transaction> getTransaction(long accountNo) {

	   List<Transaction> list = bankDao.getTransactions(accountNo);
	
	   return list;
	}

	public int passwordValidation(String password) {
		try
		{
		if(password.length()<5)
			return 1;
		else
			throw new InvalidException("Account Pin Should Be 4 digits..");
		}
		catch(InvalidException e)
		{
			System.out.println(e);
		}
			return 0;
	}

	
	public int checkBalance(int balance) {
		if(balance>=1000)
		return 1;
		else 
			return 0;
	}

	
	public int phoneNoValidation(String phoneNo) {
		try
		{
			if(phoneNo.matches("[6-9][0-9]{9}"))
					return 1;
			else
				throw new InvalidException("Mobile Number is not valid..");
				
		}
		catch(InvalidException e)
		{
			System.out.println(e);
		}
		return 0;
	}

	
	public int nameValidation(String name) {
		try
		{
		if(name.matches("[A-Z][a-zA-Z]*"))
			return 1;
		
		else
		throw new InvalidException("Name Should Start With Capital Letter..");
	}
		catch(InvalidException e)
		{
			System.out.println(e);
		}
		return 0;
	}

	class InvalidException extends Exception
	{
		private static final long serialVersionUID = 1L;
		String s1;
		InvalidException(String s)
		{
			 s1=s;
		}
		public String toString()
		{
			return (s1);
		}
	}	
}