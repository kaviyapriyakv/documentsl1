/**
 * @author KPRIYAKV
 * date : 18/10/19
 * Description : Getting user choice for banking services
 */
package com.cg.banking.view;

import java.util.Scanner;

import com.cg.banking.servicec.CustomerController;
import com.cg.banking.servicec.CustomerInterface;

public class MainBanking {

	public static void main(String[] args) {
		int choice=0;
		
		System.out.println("enter your choice");
		System.out.println("1. Create Details");
		System.out.println("2. Deposit Amount");
		System.out.println("3. Withdraw Amount");
		System.out.println("4. Transfer Amount");
		System.out.println("5. view mainbalance");
		Scanner scanner = new Scanner(System.in);
		choice = scanner.nextInt();
		CustomerInterface customer1 = new CustomerController();
		
		switch (choice) {
		case 1:
			customer1.addCustomer();
			break;
		case 2:
			System.out.println("enter the account number");
			int Accountnumber1 = scanner.nextInt();
			customer1.deposit( Accountnumber1);
			break;
		case 3:
			System.out.println("enter the account number");
			int  Accountnumber2 = scanner.nextInt();
			customer1.withdraw( Accountnumber2);
			break;
		case 4:
			System.out.println("enter your account number to transfer");
			int  Accountnumber3 = scanner.nextInt();
			System.out.println("enter the account number to transfer your money");
			int  Accountnumber4 = scanner.nextInt();
			customer1.transfer( Accountnumber3,  Accountnumber4);
			break;

		case 5:

			System.out.println("enter the account number");
			int  Accountnumber5 = scanner.nextInt();
			customer1.viewBal( Accountnumber5);
			break;

		}
	}
}
