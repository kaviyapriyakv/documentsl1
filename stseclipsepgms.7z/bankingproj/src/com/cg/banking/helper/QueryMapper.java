/**
 * @author KPRIYAKV
 * date : 18/10/19
 * Description : mapping query
 */
package com.cg.banking.helper;

public interface QueryMapper {

	public static final String VIEW_CUSTOMERS = "select * from customer";
	public static final String INSERT_CUSTOMERS = "Insert into customer values(?,?,?,?,?)";
	public static final String UPDATE_CUSTOMERS = "update customer set balance=? where accountid=?";

}
