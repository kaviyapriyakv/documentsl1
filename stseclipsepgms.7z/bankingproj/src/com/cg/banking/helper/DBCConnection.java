/**
 * @author KPRIYAKV
 * date : 18/10/19
 * Description : connecting to the database
 */
package com.cg.banking.helper;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
public class DBCConnection {
	static Connection connection = null;

	public static Connection getConnection() {

		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			connection= DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "system", "India123");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return connection;

	}

	public static void main(String[] args) {
		System.out.println(getConnection());
	}
	
}

