/**
 * @author KPRIYAKV
 * date : 18/10/19
 * Description : creating method for updating and executing details in database 
 */
package com.cg.banking.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import com.cg.banking.helper.DBCConnection;
import com.cg.banking.helper.QueryMapper;
import com.cg.banking.model.Customer;


public class DaoC implements DaoI {
	private Connection connection;
	private PreparedStatement preparedstatment;
	private ResultSet resultset;
//int balance=0;
	public int createCustomer(Customer customer) {
		//int row=0;
		try {
			connection = DBCConnection.getConnection();
			preparedstatment = connection.prepareStatement(QueryMapper.INSERT_CUSTOMERS);
			preparedstatment.setInt(1, customer.getCustomerId());
			preparedstatment.setString(2, customer.getCustomerName());
			preparedstatment.setInt(3, customer.getAccountId());
			preparedstatment.setString(4, customer.getAccountType());
			preparedstatment.setInt(5, 0);
			int row = preparedstatment.executeUpdate();
			resultset.next();
			System.out.println(row + "row is updated");
		} catch (Exception e) {
			//e.printStackTrace();
			System.err.println("error");
		}
		return 1;
	}

	public int update(Customer customer2, int accountId, int balance) {
		int row=0;
		try {
			connection = DBCConnection.getConnection();
			preparedstatment = connection.prepareStatement(QueryMapper.UPDATE_CUSTOMERS);
			preparedstatment.setInt(1, balance);
			preparedstatment.setInt(2, accountId);
			row=preparedstatment.executeUpdate();
			resultset.next();
			System.out.println(row+"row updated");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return 1;
	}

	public ArrayList<Customer> getAllCustomer() {
		ArrayList<Customer> list = new ArrayList<Customer>();
		try {
			connection = DBCConnection.getConnection();
			preparedstatment = connection.prepareStatement(QueryMapper.VIEW_CUSTOMERS);
			resultset = preparedstatment.executeQuery();
			while (resultset.next()) {
				Customer c = new Customer();
				c.setCustomerId(resultset.getInt(1));
				c.setCustomerName(resultset.getString(2));
				c.setAccountId(resultset.getInt(3));
				c.setAccountType(resultset.getString(4));
				c.setBalance(resultset.getInt(5));
				list.add(c);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}

	public int MainBalance(int accountId) {
		int balance1 = 0;
		// System.out.println(accountId);
		try {
			connection = DBCConnection.getConnection();
			preparedstatment = connection.prepareStatement("select balance from customer where accountId=" + accountId);
			resultset = preparedstatment.executeQuery();
			resultset.next();
			balance1 = resultset.getInt(1);
			//System.out.println(balance1);
		} catch (Exception e) {
			e.printStackTrace();
		}
		//System.out.println(balance1);
		return balance1;
	}
	
	

	
}
