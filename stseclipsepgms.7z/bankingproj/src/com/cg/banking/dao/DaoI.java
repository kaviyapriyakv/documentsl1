/**
 * @author KPRIYAKV
 * date : 18/10/19
 * Description : declaring methods of DaoC class
 */
package com.cg.banking.dao;

import java.util.ArrayList;


import com.cg.banking.model.Customer;


public interface DaoI {

	public int createCustomer(Customer cutomer);

	
	ArrayList<Customer> getAllCustomer();

	public int MainBalance(int accountId);


	int update(Customer customer2, int accountId, int balance);

}
