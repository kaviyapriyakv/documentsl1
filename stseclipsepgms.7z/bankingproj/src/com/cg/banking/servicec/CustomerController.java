/**
 * @author KPRIYAKV
 * date : 18/10/19
 * Description : creating methods for create details,deposit amount,withdraw amount,view balance and transfer amount
 */
package com.cg.banking.servicec;

import java.util.ArrayList;

import java.util.List;
import java.util.Scanner;

import com.cg.banking.dao.DaoC;
import com.cg.banking.dao.DaoI;
import com.cg.banking.model.Customer;

public class CustomerController implements CustomerInterface {

	Customer customer2;
	DaoI dao = new DaoC();
	Scanner scanner2 = new Scanner(System.in);
	//int balance = 0;

	public void addCustomer() {

		System.out.println("enter customer id:");
		int customerId = scanner2.nextInt();
		System.out.println("enter customer name");
		String customerName = scanner2.next();
		System.out.println("enter account id:");
		int accountId = scanner2.nextInt();
		System.out.println("enter account type");
		String accountType = scanner2.next();
		customer2 = new Customer();
		customer2.setCustomerId(customerId);
		customer2.setCustomerName(customerName);
		customer2.setAccountId(accountId);
		customer2.setAccountType(accountType);
		customer2.setBalance(0);
		
		System.out.println("customer created");
	
		int status = dao.createCustomer(customer2);
		if (status == 1) {
			System.out.println("Customer added");
		} else {
			System.out.println("please check");

		}
	}

	public void deposit(int accountId) {
		Customer customer1 = new Customer();
	int balance2;
		System.out.println("enter the amount to deposit");
		int amountD = scanner2.nextInt();
		int balance = dao.MainBalance(accountId);
		 balance2 = balance + amountD;
		int status = dao.update(customer1, accountId, balance2);
		if (status == 1) {
			System.out.println("Money Deposited Successfully");
		} else {
			System.out.println("please check");

		}
	}

	public void withdraw(int accountId) {

		System.out.println("enter the amount to withdraw");
		int amountW = scanner2.nextInt();
		
		int balance = dao.MainBalance(accountId);

		int balance1 = balance - amountW;
		if (balance1 > 100) {

			int status = dao.update(customer2, accountId, balance);
			if (status == 1) {
				System.out.println("Money Withdrawn Succesfully");

			} else {
				System.out.println("please check");

			}
		} else {
			System.out.println("balance insufficient");
		}
	}

	public void transfer(int accountNumberS, int accountNumberR) {

		System.out.println("enter your amount to transfer");
		int amountT = scanner2.nextInt();
		dao = new DaoC();
		int balanceS = dao.MainBalance(accountNumberS);
		int balanceR = dao.MainBalance(accountNumberR);
		balanceS = balanceS - amountT;
		if (balanceS > 100) {
			int status = dao.update(customer2, accountNumberS, balanceS);
			balanceR = balanceR + amountT;
			int state = dao.update(customer2, accountNumberR, balanceR);
			if (status == 1 && state == 1) {

				System.out.println("Rs." + amountT + " transferred successfully from " + accountNumberS + " to " + accountNumberR);

			} else {
				System.out.println("please check");
			}
		} else {
			System.out.println("balance insufficient");
		}
	}

	public void viewBal(int accountId) {
		dao = new DaoC();
		int balance = dao.MainBalance(accountId);
		System.out.println("your current balance is : " + balance);

	}

}
