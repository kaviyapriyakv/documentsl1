/**
 * @author KPRIYAKV
 * date : 18/10/19
 * Description : declaring methods of CustomerController class
 */
package com.cg.banking.servicec;

public interface CustomerInterface {
	public void deposit(int accountId);

	public void withdraw(int accountId);

	public void transfer(int accountnumberS, int accountnumberR);

	public void viewBal(int accountId);

	public void addCustomer();

	

}
