package com.cg.banking.model;

public class Customer {
	private int customerId;
	private String customerName;
	private int accountId;
	private String accountType;
	private int balance;
	public Customer() {
		
	}
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public int getAccountId() {
		return accountId;
	}
	public void setAccountId(int accountId) {
		this.accountId = accountId;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public int getBalance() {
		return balance;
	}
	public void setBalance(int balance) {
		this.balance = balance;
	}
	@Override
	public String toString() {
		return "Costomer [customerId=" + customerId + ", customerName=" + customerName + ", accountId=" + accountId
				+ ", accountType=" + accountType + ", balance=" + balance + "]";
	}
}
	