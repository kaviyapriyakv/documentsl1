package com.cg.banking.model;

public class User {
private String uername;
private String password;
@Override
public String toString() {
	return "User [uername=" + uername + ", password=" + password + "]";
}
public String getUername() {
	return uername;
}
public void setUername(String uername) {
	this.uername = uername;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}


}
