package com.cg.cartest.runner;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(features="feature",
glue="com.cg.cartest.stepdefinition",dryRun=false)
public class CarRunner {

}
