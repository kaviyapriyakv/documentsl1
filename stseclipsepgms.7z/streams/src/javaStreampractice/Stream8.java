package javaStreampractice;

import java.util.Arrays;
import java.util.IntSummaryStatistics;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.stream.Collectors;

public class Stream8 {

	public static void main(String[] args) {
		long count, count1;

		// List<String> strings
		// =Arrays.asList("Rat","","cat","lion","tiger","","fly","rooster","Rat");
		List<Integer> number = Arrays.asList(3, 2, 4, 5, 3, 6);
		System.out.println("Using java 8");
		IntSummaryStatistics st = number.stream().mapToInt((x) -> x).summaryStatistics();
		System.out.println(st.getMax());
		System.out.println(st.getMin());
		System.out.println(st.getAverage());
		System.out.println(st.getSum());
		Random random = new Random();// prints10 random numbers
		for (int i = 1; i <= 10; i++) {
			System.out.println("Random  " + i + "" + random.nextInt());
		}
		random.ints().limit(10).sorted().forEach(System.out::println);

		// System.out.println("list:"+strings);
		// Set<String>filtered
		// =strings.stream().filter(string->!string.isEmpty()).collect(Collectors.toSet());//to
		// remove the empty string
		// String mergedString
		// =strings.stream().filter(string->!string.isEmpty()).collect(Collectors.joining("
		// , "));//to merge strings
		// List<String>filtered
		// =strings.stream().filter(string->!string.isEmpty()).collect(Collectors.toList());//to
		// remove the empty string
		// count1=strings.stream().filter(string->string.isEmpty()).count();
		// count=strings.stream().filter(string->string.length()==3).count();
		List<Integer> squaresList = number.stream().map(i -> i * i).distinct().collect(Collectors.toList());
		// System.out.println(count1);
		// System.out.println(count);
		/*
		 * System.out.println("Filteredlist:"+filtered);
		 */// System.out.println("mergedlist:"+mergedString);
		System.out.println("sqrslist:" + squaresList);
	}
}
