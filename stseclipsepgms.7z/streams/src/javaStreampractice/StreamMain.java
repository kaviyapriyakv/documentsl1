package javaStreampractice;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class StreamMain {
	//private static int getCountEmptyStringUsingjava7(List<String>string) {
	
		/*int count=0;
		for(String s:string) {
			if(s.isEmpty()) {
			{
				count++;
			}
		}return count;
	
	}
	private static int getCountLengthStringUsingjava7(List<String>string) {
		int count=0;
		for(String s:string) {
			//if(s.isEmpty()) {
			if(s.length()==3) {
				count++;
			}
		}return count;
	}*/
	/*private static List<String> deleteEmptyStringUsingjava7(List<String>string) {
		List<String>filteredlist=new ArrayList<String>();
		System.out.println();
		for(String  s:string) {
			if(!s.isEmpty()) {
				filteredlist.add(s);
			}
		}return filteredlist;
	}*/
	private static String getMergeStringUsingjava7(List<String>string,String seperator) {
		StringBuilder stringbuilder=new StringBuilder();
		
		for(String  s:string) {
			if(!s.isEmpty()) {
				stringbuilder.append(string);
				stringbuilder.append(seperator);
			}
		}
		String mergedString=stringbuilder.toString();
		return mergedString.substring(0,mergedString.length()-1);
	}
	
	
	
	
	
	
	public static void main(String[] args) {
		List<String> string =Arrays.asList("Rat","","cat","lion","tiger","","fly","rooster");
		
	/*System.out.println("list:"+ string);
	System.out.println(getCountEmptyStringUsingjava7(string));
	System.out.println(getCountLengthStringUsingjava7(string));*/
	//System.out.println(deleteEmptyStringUsingjava7(string));
		System.out.println(getMergeStringUsingjava7(string,"," ));
	}

}
