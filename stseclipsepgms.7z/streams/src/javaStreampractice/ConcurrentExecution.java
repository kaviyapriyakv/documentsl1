package javaStreampractice;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ConcurrentExecution {
private final ConcurrentHashMap<Integer,String>	conHashMap=new ConcurrentHashMap<Integer,String>();

public static void main(String[] args) {
	ExecutorService service =Executors.newFixedThreadPool(3);
	service.execute(obj.new WriteThreadone());
	service.execute(obj.new WriteThreadone());
	service.execute(obj.new WriteThreadone());


class WritethreaOne implements Runnable{
		public void run() {
			for(int i=1;i<=10;i++) {
				conHashMap.putIfAbsent(i,"A"+i);
				
			}
		
		
class WritethreaOne implements Runnable{
				public void run() {
					for(int i=1;i<=4;i++) {
						conHashMap.putIfAbsent(i,"B"+i);
						
					}
				
		
		
		
		}
		
		
		
	}