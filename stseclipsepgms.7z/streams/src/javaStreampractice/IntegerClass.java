package javaStreampractice;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class IntegerClass {
	public static void main(String[] args) {
		
	List<Integer> number=Arrays.asList(3,2,4,5,3);
	int squaresList=getSquares(number);
	System.out.println("sqList:"+ squaresList);
	List<Integer>integer=Arrays.asList(1,13,12,4,2,17,15);	
	System.out.println("List:"+ integer);
	System.out.println("highest num:"+ getMax(integer));
	System.out.println("lowest num:"+ getMax(integer));
	System.out.println("sum is:"+ getSum(integer));
	System.out.println("Average is:"+ getAvg(integer));

	
}

	private static int getSquares(List<Integer> number) {
		// TODO Auto-generated method stub
		
		
		return 0;
	}

	private static int getAvg(List<Integer> integer) {
		// TODO Auto-generated method stub
		return 0;
	}

	private static int getSum(List<Integer> integer) {
		// TODO Auto-generated method stub
		
		return 0;
	}

	private static int getMax(List<Integer> integer) {
		int max =integer.get(0);
		for(int i=1;i<integer.size();i++) {
			Integer num =integer.get(i);
			if(num.intValue()>max) {
				max=num.intValue();
			}}
		
		
		// TODO Auto-generated method stub
		return 0;
	}}
