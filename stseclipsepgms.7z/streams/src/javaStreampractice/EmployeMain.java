package javaStreampractice;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Stream;

public class EmployeMain {
public static void main(String[] args) {
	Employee emp[]= {new Employee("sharuk","khan","IT",90000),
			new Employee("amir","khan","Sales",100000),
			new Employee("ranver","singh",",marketing",900000),                                          
	        new Employee("suriya","sivakumar","marketing",560000),
	        new Employee("ranbir","kapoor","ITi",700000),
	        new Employee("alia","bhatt","sales",4560000),
	        new Employee("Aiswarya","roy","",90000)};
	List<Employee> list =Arrays.asList(emp);
	
	
	/*System.out.println("list of employees:");
	list.stream().forEach(System.out::println);
	System.out.println("emp sorted by salary");
	Predicate<Employee>forty2sixty=e->(e.getSalary()>=500000 && e.getSalary()<=900000);
list.stream().filter(forty2sixty).sorted(Comparator.comparing(Employee::getSalary)).forEach(System.out::println);
System.out.println("display first emplyee sorted by salary"+ list.stream().filter(forty2sixty).findFirst().get());
*/
	Predicate<Employee>forty2sixty=e->(e.getDepartment().isEmpty());
	list.stream().filter(forty2sixty).sorted(Comparator.comparing(Employee::getDepartment)).forEach(System.out::println);
//	System.out.println("display dept without emp"+ list.stream().filter(forty2sixty).findFirst().get());
	
/*System.out.println("list of employees:");
list.stream().forEach(System.out::println);
System.out.println("emp sorted by firstnme");

//list.stream().filter(forty2sixty).sorted(Comparator.comparing(Employee::getFirstname())).forEach(System.out::println);
// list.stream().map(Employee::getFirstname).sorted().forEach(System.out::println);//for sorting by firstname
Function<Employee,String>byFirstName=Employee::getFirstname;
Function<Employee,String>byLastName=Employee::getLastname;

Comparator<Employee>lastThenFirst=Comparator.comparing(byLastName).thenComparing(byFirstName);
list.stream().sorted(lastThenFirst).map(Employee::getName).forEach(System.out::println);
*/
}}



