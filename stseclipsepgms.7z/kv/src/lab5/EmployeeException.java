package com.cg.eis.exception;

import java.util.Scanner;

public class EmployeeException extends RuntimeException{
	public EmployeeException()
	{
		System.out.println("salary cannot be below 3000");
	}
	public void EmployeeExceptionn(String s)
	{
		System.out.println(s);
	}
public static void main(String[] args) {
Scanner s =new Scanner(System.in);
int n=s.nextInt();

	try {   
		if(n<3000)
		{
		throw new EmployeeException();
		}}
	catch(EmployeeException e)
	{
			System.out.println(e);
	}

}}
	


