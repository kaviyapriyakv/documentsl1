package javapractice;

public class Sum {
	int sum = 0; 
	
	
	int calculateSum (int n) {
		
		if(sum%3==0 && sum%5==0)
		{
			for(int i=0;i<n;i++)
			{
				
				sum= sum+i;
			}
		}
		return sum;
	}public static void main(String[] args)
	{
		Sum c= new Sum();
	int a=	c.calculateSum(20);
		System.out.println(a);
		
	}
	

}
