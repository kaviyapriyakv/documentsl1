package javapractice;

public class Different {
	int sum=0,sq=0;
	int calculateDifference(int n)
	{
		for(int i=1;i<=n;i++)
		{sum=sum+(i*i);
		sq=sq+i	;
		
		}
	
int r =sq*sq;
int Sum;
Sum=r-sum;
	
return Sum ;
	}
public static void main(String args[]) {

Different d=new Different();
int a=d.calculateDifference(5);
System.out.println(a);
}}
