package javapractice;

import java.util.Arrays;

public class IntergerSort {
	int[] getSorted(int[] arr) {
		int temp;
		int[] a = new int[arr.length];
		int l = arr.length;
		int l1 = l;
		for (int i = 0; i < l; i++) {
			a[l1 - 1] = arr[i];
			l1 = l1 - 1;
		}
		for (int j = 0; j < a.length; j++) {
			for (int k = j + 1; k < a.length; k++) {
				// 7
				if (a[j] > a[k]) {
					temp = a[j];
					a[j] = a[k];
					a[k] = temp;
				}

			}
		}
		return a;
	}

	public static void main(String[] args) {
		IntergerSort s = new IntergerSort();
		int ar[] = { 1, 3, 4, 2, 5 };
		int array[] = s.getSorted(ar);

		System.out.println(Arrays.toString(array));

	}

}
