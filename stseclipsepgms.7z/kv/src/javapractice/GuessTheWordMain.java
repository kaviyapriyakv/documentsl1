package javapractice;
import java.util.*;
public class GuessTheWordMain {
	public static void main(String[] args){
		GuessTheWord guessTheWord=new GuessTheWord();
		Scanner scan=new Scanner(System.in);
		System.out.println("enter the no of quues to be answer");
		int noofques= scan.nextInt();
		guessTheWord.displayQuesion(noofques);
	}

}
