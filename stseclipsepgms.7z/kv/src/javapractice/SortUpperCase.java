package javapractice;

import java.util.Arrays;
import java.util.Scanner;

public class SortUpperCase {
	
		public static void main(String[] args)
		{
			Scanner s =new Scanner(System.in);
			int l=s.nextInt();
			String[] array= new String[l];
			
			for(int i=0;i<l;i++)
				array[i]=s.next();
		s.close();
		SortUpperCase e=new SortUpperCase();
		e.sor(array);
		for(int i=0;i<l;i++)
		{
			System.out.println(array[i]);	
		}
		}
	private	void sor(String[] array)
		{
			for(int i=0;i<array.length;i++)
			{
				for(int j=0;j<array.length;j++)
				{
					if(array[i].charAt(0)<array[j].charAt(0))
					{
						String temp;
						temp=array[i];
						array[i]=array[j];
						array[j]=temp;
					}
				}	
			}
		
		for(int i=0;i<array.length/2;i++)
			array[i]=array[i].toUpperCase();
		for(int j=array.length-1;j>array.length/2;j--)
			array[j]=array[j].toLowerCase();
		}
	}


	
/*	void getUppercaseArray(String[] arr) {
		int l = arr.length;
		Arrays.sort(arr);
		if (l % 2 == 0) {
			for (int i = 0; i < l / 2; i++) {
				arr[i] = arr[i].toUpperCase();

			}
		} else if (l % 2 != 0) {
			int i = (l / 2) + 1;

			for (int j = 0; j < i; j++) {
				arr[j] = arr[j].toLowerCase();
			}
			System.out.println(arr);
		}
	}

	public static void main(String[] args) {
		SortUpperCase s = new SortUpperCase();
		String e[] = { "ramya", "kaviya", "aarthi", "divya" };
		s.getUppercaseArray(e);

	}
}*/
			
		
		
		
		
		
		
		
		
	
	
	
	
	
	


