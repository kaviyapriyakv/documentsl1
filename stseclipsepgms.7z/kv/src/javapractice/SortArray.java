package javapractice;

import java.util.Arrays;

public class SortArray {
	void getSecondSmallest(int[] arr) {
		
	Arrays.sort(arr);
	System.out.println(arr[1]);
	//return 0;

}
public static void main(String args[])
{
	SortArray s=new SortArray();
	int i[]={1,3,4,2,5};
	s.getSecondSmallest(i);
	
	
}}