package javapractice;

public class StringLiterals {
public static void main(String[] args) {

	String s= "chennai,hydrabad,delhi,banglore";
	String e[]=s.split(",");
	
	System.out.println(e);
	
	
}
}