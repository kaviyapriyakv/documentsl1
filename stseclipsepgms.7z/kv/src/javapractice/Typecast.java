package javapractice;

public class Typecast {
	
}
class Java extends Typecast
{
	
class Type{
	public void main(String[] args) {
		Typecast t=new Typecast();
		Java j=new Java();
		
		Typecast t1=j;
		Java j1=(Java) t;
		
}}
	
}
