package javapractice;

import java.util.Scanner;

public class Check {
	
		public static void main(String[] arg)
		{
			int num;
			boolean z;
			Scanner s=new Scanner(System.in);
			num=s.nextInt();
				s.close();
			z=Check.checkNumber(num);
			if(z)
				System.out.println("increasing number");
			else System.out.println("not a increasing number");	
		}
		public static boolean checkNumber(int n)
		{
			int r=n%10;
			int s=n/10;
			int count =0,i=0;
			while(n!=0)
			{
				count++;
				n/=10;
			}
			int y=count;
			while(count!=0)
			{
				if(r>(s%10))
				{
					r=s%10;
					s=s/10;
					i++;
					
				}count--;
				
			}
		if(y==i)
		{
			return true;
			
		}
		else
		{
			return false;
		}
		}
		}
		
/* int i,n;
 }
 i=number%10;	 
 n=number/10;
 int m=n%10;
 boolean x=false;
	
    if(m<i)
       {x=true; 
    	i=number%10;
       n=number/10;
       m=n%10;
	 }
	 
		 	   
	 return x ;
 }
	 public static void main(String args[]) {
	 
		 Check c= new Check();
		 boolean a=c.checkNumber(13417);
		 System.out.println(a);
	 }}
	 
 
	*/
	

