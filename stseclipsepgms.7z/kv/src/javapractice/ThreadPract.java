package javapractice;

/*public class ThreadPract  {
	


	public void run() {
		for (int i = 0; i < 6; i++) {
			System.out.println(i);
		}
	}
	public static void main(String[] args) {
		System.out.println("thread started");
		ThreadPract t = new ThreadPract();
		
		t.run();
		System.out.println("thread ended");

	}
}

public class ThreadPract implements Runnable {

	public void method() {
		try {
			for (int i = 1; i <= 6; i++) {
				System.out.println(i);

				Thread.sleep(1000);
			}
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		
		
	}
	
}
public void run() {
	n.method();
}

		
	

	public static void main(String[] args) {
		System.out.println("thread started");
		ThreadPract t = new ThreadPract();
		Thread t1 = new Thread(t);
		Thread t2 = new Thread(t);
		t1.start();
		t2.start();
		System.out.println("thread ended");

	}


*/
	