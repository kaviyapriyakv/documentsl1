package javapractice;

public class CheckPower {

	boolean checkNumber(int n)
	{
		while (n != 1) 
        { 
            if (n % 2 != 0)      	
           {     
            	return false; 
           
        } 
        return true; 
    } return false;
	}
	
	public static void main(String args[])
	{
		CheckPower c= new CheckPower();
		boolean l =c.checkNumber(31);
		System.out.println(l);
	}
}
