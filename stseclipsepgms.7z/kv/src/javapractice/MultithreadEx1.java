package javapractice;
import java.io.*;

public class MultithreadEx1 implements Runnable{
	
	
	    public void run() {
	        FileReader f = null;
	        FileWriter f1 = null;
	        BufferedReader br = null;
	        BufferedWriter bw = null;
	        
	        String line = "";
	        try {
	            f = new FileReader("source.txt");
	            f1 =new FileWriter("C:\\\\Users\\\\KPRIYAKV\\\\practice.java", true);
	            br = new BufferedReader(f);
	            bw = new BufferedWriter(f1);
	            line = br.readLine();
	            
	            while(line != null) {
	                System.out.println(line);
	                bw.write(line.toString());
	                bw.flush();
	                line = br.readLine();
	            }
	            f1.close();
	        }
	        catch(Exception e) {
	            System.out.println(e);
	        }}

	    public static void main(String[] args) {
	    	MultithreadEx1 obj = new MultithreadEx1();
	        Thread th = new Thread(obj);
	        th.start();
	    }
	


}


