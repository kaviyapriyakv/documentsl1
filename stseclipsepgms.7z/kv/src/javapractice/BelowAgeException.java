package javapractice;

import java.util.Scanner;

public class BelowAgeException extends RuntimeException{ 
	
		public BelowAgeException()
		{
			System.out.println("age should be above 15");
		}
		public void BelowAgeException(String s)
		{
			System.out.println(s);
		}
	public static void main(String[] args) {
	Scanner s =new Scanner(System.in);
	int n=s.nextInt();

		try {   
			if(n<15)
			{
			throw new BelowAgeException();
			}}
		catch(BelowAgeException e)
		{
				System.out.println(e);
		}

	}}
		

