package javapractice;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;

public class LineNumbers {
	public static void main(String[] args) throws FileNotFoundException  {
		
	
	 

		FileReader f = new FileReader("C:\\Users\\KPRIYAKV\\practice.java");
	
	 BufferedReader reader = new BufferedReader(f); 

	
	
	
	}
}
