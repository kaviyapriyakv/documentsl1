package javapractice;

public class Operators {
	void sumOfCubes(int number) {
		
		int sum=0;
		while(number!=0) {
			{int digit= number%10;
			sum=sum+digit*digit*digit;
			number=number/10;
			} 
		}
		System.out.println(sum);
		
	}public static void main(String args[]) {
		Operators o=new Operators();
		o.sumOfCubes(233);
	}
	
	
	

}
