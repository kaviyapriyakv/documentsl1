package javapractice;

import java.util.Scanner;

public class TraficLight {
	

	
	public static void main(String[] args) {
	Scanner t=new Scanner(System.in);
	String s=t.nextLine();
	if(s.equals("red")) {
		System.out.println("stop");
		
	}else if(s.equals("yellow")) {
		System.out.println("be ready");
	}else if(s.equals("green")) {
		System.out.println("go");
	}
		
		
		
		
	}
	
}
