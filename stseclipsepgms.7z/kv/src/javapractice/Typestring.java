package javapractice;

public class Typestring {
	public static void main(String args[])
	{
		String s1="welcome";
		
		for(int i=0;i<s1.length();i++)
		{
			System.out.print(s1.charAt(i)+" ");
		}
	}
	
	
	
	

}
