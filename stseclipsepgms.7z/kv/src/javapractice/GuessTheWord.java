package javapractice;
import java.util.*;
public class GuessTheWord {
	String []Quesion= new String[5];
	String []Answer= new String[5];
	static Scanner scanner=new Scanner(System.in);
	String s;
	double score,scorePercentage;
	 GuessTheWord()
	 {
String Question[]= {"c__n_i","b_nglo__","","",""};
String Answer[]= {"chennai","banglore","mumbai","delhi","hydrabad"};		
		this.Quesion=Quesion;
       this. Answer=Answer;
	 }
		void displayQuesion(int noofques) {
			if(noofques<0||noofques>5)
			{
				System.out.println("not a valid input");
				System.exit(0);
			}else
			{
				for(int i=0;i<noofques;i++)
				{   System.out.println("Question"+i+1+"i");
					System.out.println(Quesion[i]);
				     s=scanner.next();
				boolean result=verifyAnswer(i);
				if(result=true)
				{
					score+=calculateScore();
				}
				}
			}displayScore(noofques);
			
				
				}
				
			boolean verifyAnswer(int index){
				boolean status=false;
			    if(s.equalsIgnoreCase(Answer[index]))
			    {
			    	status=true;
			    }else
			    	status=false;
				return status;
			
		}
		
	 
	int calculateScore()
	{
		int score=10;
		return score;
	
	}
	void displayScore(int noofques)
	{System.out.println("Score:"+ score);
		scorePercentage =((score/noofques)*100);
		
	}}
