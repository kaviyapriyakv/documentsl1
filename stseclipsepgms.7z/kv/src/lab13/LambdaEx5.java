package labbook13;
import java.util.function.Function;
public class LambdaEx5 {
	
		public static void  main(String[] arg)
		{
		
			LambdaEx5 p=new LambdaEx5();
			Function<Integer,Integer> h=p::fact1;
				int y=h.apply(5);
				System.out.println(y);
			
		}
				public int fact1(int x)
				{

		int factres=1;
		return factres;	



				}}
