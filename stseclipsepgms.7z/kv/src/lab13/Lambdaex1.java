package labbook13;

public interface Lambdaex1 {
	
	    public int cal(int x,int y);
	    public static void main(String[] args)
	    {
	    	Lambdaex1 p=(v,z)->{
	        int res=1;
	        for(int i=1;i<=z;i++)
	        res=res*v;
	        return res;
	    };
	    int res=p.cal(2, 3);
	    System.out.println(res);
	    }

	    }
	 




