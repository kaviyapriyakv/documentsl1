package javapract;
import java.util.*;
public class NegativeAgeException extends RuntimeException{
	public NegativeAgeException()
	{
		System.out.println("age cannot be a negative");
	}
	public NegativeAgeException(String s)
	{
		System.out.println(s);
	}
public static void main(String[] args) {
Scanner s =new Scanner(System.in);
int n=s.nextInt();

	try {   
		if(n<0)
		{
		throw new NegativeAgeException();
		}}
	catch(NegativeAgeException e)
	{
			System.out.println(e);
	}

}}
	
	
