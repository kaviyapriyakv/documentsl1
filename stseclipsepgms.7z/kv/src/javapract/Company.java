package javapract;
/*
public class Company {
	final String cmpname = "adsjhssk";
	int workerstrength = 10;
}
class Employee extends Company
{
	int empid=1;
	
}
class FemaleEmployee extends Employee
{
	int female =5; 

 int getEmployeedetails(int empid ,int workstregth)
 {
	 this.empid=empid;
	 this.workerstrength=workerstrength;
	 return empid+""+workerstrength;
	 
 }
 
 class  Sector{
	 public  void main(String args[]) {
		 
		FemaleEmployee e = new FemaleEmployee();
		System.out.println(e instanceof FemaleEmployee);
		System.out.println(e.empid);
		System.out.println(e.female);
		  
		
		
		
	 }}}
	

*/