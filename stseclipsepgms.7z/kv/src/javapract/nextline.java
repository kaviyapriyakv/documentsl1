package javapract;
import java.util.*;
public class nextline {
public static void main (String[] args)	{
	Scanner s1=new Scanner(System.in);
	Scanner s2=new Scanner(System.in);
	String a=s1.next();
	String b=s2.nextLine();
	System.out.println(a);
	System.out.println(b);
}

}
