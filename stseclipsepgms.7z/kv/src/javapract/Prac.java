package javapract;

public class Prac {
	
	
		int num=5; 
		
	class Rev extends Prac
	{
		String l="sjdbfh";
	}

	 public static void main(String args[]) {
	Prac e = new Prac();
	boolean s=e instanceof Prac;
				System.out.println(s);
			

}}
