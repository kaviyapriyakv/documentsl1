package javapract;

public class Parse {
	public static void main(String[] args)
	{
		//String s="12";
		//String s1="hello";
		//int []a= {2,4,6,7,9};
		//System.out.println(a[5]);
		//Integer i= Integer.parseInt(s);
		//Integer j= Integer.parseInt(s1);
        //System.out.println(i);
        //System.out.println(j);
		try {System.out.println("line1");
			int x=10/0;
			System.out.println("line2");
			try {
				System.out.println("line1");
				String s="12";
				Integer i= Integer.parseInt(s);
			}
			catch(NumberFormatException s)
			{
				System.out.println("except" + s);
			}
		}catch(ArithmeticException s)
		{
			s.printStackTrace();
			System.out.println("exception");
		}
	

finally {
	System.out.println("gets executed");
}}}

