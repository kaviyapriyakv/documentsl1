package javapract;
interface FuncInter
{
	public int display(int i,int j);
		
	
	public default void play() {
		
	System.out.println("playing");
	
	}
}
public class MyClass {
public static void main(String[] args){
	
	FuncInter f=(int i,int j)->(i+j) ;
	System.out.println(f.display(3,5));
	/*int r=f.display(3,5);
	f.play();*/
}
}
