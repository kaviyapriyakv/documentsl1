package javapract;
enum Edge{
	TOP,BOTTOM,LEFT,RIGHT;
}

public class EnumExp {
	public static void main(String[] args) {
		Edge e=Edge.TOP;
		int i=e.ordinal();
				System.out.println(e);
		System.out.println(i);
	}

}
