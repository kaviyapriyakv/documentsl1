package javapract;

class Thread1 {
	int n;
	boolean a = false;

	synchronized int get() {
		if (!a) {
			try {
				wait();
			} catch (InterruptedException e1) {

				e1.printStackTrace();
			}
			String name = Thread.currentThread().getName();
			System.out.println(name + "" + n);
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				
				e.printStackTrace();
			}
			a = false;
			notify();

		}
		return n;
	}

	synchronized int put(int n) {

		if (a) {
			try {
				wait();
			} catch (InterruptedException e1) {
				
				e1.printStackTrace();
			}
			this.n = n;
			String name = Thread.currentThread().getName();
			System.out.println(name + "" + n);
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {

				e.printStackTrace();
			}
			a = true;
			notify();

		}
		return n;
	}
}

class Producer implements Runnable {
	Thread1 t3;

	public Producer(Thread1 t2) {
		this.t3 = t2;
		new Thread(this, "producer").start();
	}

	public void run() {
		// String name = Thread.currentThread().getName();
		int x = 0, i = 0;
		while (x < 10) {
			t3.put(i++);
			x++;
		}
	}
}

class Consumer implements Runnable {
	Thread1 t2;

	public Consumer(Thread1 t2) {
		this.t2 = t2;
		new Thread(this, "consumer").start();
		
	}

	public void run() {
		// String name = Thread.currentThread().getName();
		int x = 0;
		while (x < 10) {
			t2.get();
			x++;
		}
	}
}

public class ProducerConsumer {
	public static void main(String[] args) {
		Thread1 t = new Thread1();
		new Producer(t);
		new Consumer(t);
	}
}
