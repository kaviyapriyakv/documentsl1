package javapract;
import java.util.*;
/*
public class Display {
	public static void main(String args[]) {
			
		Scanner s=new Scanner(System.in);
		char a='y';
		do{
			System.out.println("hello");
			System.out.println("do we want to display it again");
			
			String c=s.nextLine();
			char n=c.charAt(0);
		}while(n==a);
		
		System.out.println("end");
	
	
	}

	
	
	

}
*/