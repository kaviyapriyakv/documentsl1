package javapract;
/*
public class Student {
	int rol;
	String name;
 Student(int rol, String name) {
	this.rol=rol;
	this.name=name;
	}
// public boolean equals(Student s) {
	//boolean res=false;
	//if(rol==s.rol && name.equals(s.name)) {
		//return true;
		
	//}
	//return res;
	 
	 //}
 //public int hashcode() {
	
	// return 22;
// }
 public class HashSetExample{
public static void main(String[] args) {
	Student s1=new Student(1,"sange");

	if(s1.equals(s2)) {
		System.out.println("true");
	}else
	{
		System.out.println("false");
	}
}
*/

