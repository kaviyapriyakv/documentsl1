package javapract;
import java.util.*;
public class Throwcatch {
	public static void main(String []args)throws InterruptedException
	{
		Scanner s=new Scanner(System.in);
		int i= s.nextInt();
		
		if(i<0)
		{
			
			
			throw new InterruptedException();
				
			
		}
	}
	
	

}
