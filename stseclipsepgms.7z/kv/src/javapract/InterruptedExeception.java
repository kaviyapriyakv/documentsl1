package javapract;

public class InterruptedExeception extends Exception {

}
