package javapract;
import java.util.Scanner;
public class Menu {
	
		public static void main(String[] args) 
		    { 
	
    System.out.println(" MAIN MENU OPTION:");
    System.out.println("1.START");
    System.out.println("2.INSTRUCTION");
    System.out.println("3.EXIT");
    System.out.println("ENTER YOUR CHOICE");
    Scanner sc=new Scanner(System.in);
    int c=sc.nextInt();
    
    switch(c)
    {
    case 1:
    	c=1;
    	startgame();
    	break;
    case 2:
    	c=2;
    	displayinstruction();
    	break;
    case 3:
    	c=3;
    	systemexit();
    	break;
    default:
    	System.out.println("not a valid input");
    
		    }}

	    static void systemexit() {
			// TODO Auto-generated method stub
		   ;}
		static void displayinstruction() {
			// TODO Auto-generated method stub
			System.out.println("DJKGRPDKKGPODK");
		}

		 static void startgame() {
			// TODO Auto-generated method stub
			 System.out.println("WELCOME TO GUESS THE NAME GAME");
			   System.out.println("PLEASE ENTER YOUR NAME");
			  Scanner s=new Scanner(System.in);
			  String name=s.nextLine();
			  System.out.println("WELCOME" +  name);
			  System.out.println("please choose a category");
			  System.out.println("1.CITY NAMES");
			  System.out.println("2.FAMOUS PERSONALITY NAME");
			  System.out.println("3.MOVIE NAMES");
			  Scanner e=new Scanner(System.in);
			  int category=e.nextInt();
			  
		switch(category)
			    {
			    case 1:
			    	category=1;
			    	System.out.println("YOU CHOOSE TO IDENTIFY CITY NAMES");
					System.out.println("YOU HAVE THREE ATTEMPTS TO FIND THE NAME");
					System.out.println("H C E A N I N");
					System.out.println("ATTEMPT 1");
					Scanner a=new Scanner(System.in);
					String ans=a.nextLine();
					String str="CHENNAI";
					
					if(ans==str)
					{
						System.out.println("15POINTS");
					}else
					{
						System.out.println("ATTEMPT 2");
					}
					
					
			    case 2:
			    	category=2;
			    	
			    	break;
			    case 3:
			    	category=3;
			    	break;
			  
			  
			  
				  
				  
			 
		}}}

		