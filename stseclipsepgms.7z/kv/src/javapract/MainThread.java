package javapract;

import java.util.concurrent.*;

class Thread3 implements Callable {
	public Object call() {
		try {
			for (int i = 1; i <= 7; i++) {
				Thread.sleep(1000);
				System.out.println("i=" + i);
			}
		} catch (Exception ie) {
			System.out.println("Exception");
			
		}
		return "job Done";
	}}

public class MainThread {
	public static void main(String[] args) {
		System.out.println("main started");
		try {
			for(int i=1;i<=2;i++) {
				ExecutorService executor =Executors.newFixedThreadPool(2);
				Future future =executor.submit(new Thread3());
				System.out.println("Task from Future"+ future.get());
				
			}
		}
	catch(InterruptedException | ExecutionException ie) {
		System.out.println("Exeception");
	}
	System.out.println("Main Ended");
	
	
	
	
	}

}
