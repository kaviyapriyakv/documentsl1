package com.cg;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class HeaderServlet extends HttpServlet{
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		PrintWriter out=response.getWriter();
		out.println("<html><body>");
		out.println("<table>");
		//super.doGet(request, response);
		Enumeration<String> headernames=request.getHeaderNames();
		while(headernames.hasMoreElements()) {
			String name=headernames.nextElement();
			String value=headernames.nextElement();
			out.println("<tr>");
			
			out.println("<td>");out.println(name);out.println("</td>");
			out.println("<td>");out.println(value);out.println("</td>");
			
			out.println("</tr>");
		}
		
		
		out.println("</table>");
		out.println("</body></html>");
		
	}

}
