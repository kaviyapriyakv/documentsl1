package com.cg.bankapp.exception;

public class BankingException extends Exception {
	public BankingException() {
		super();
	}
	public BankingException(String s) {
		super(s);
	}
}
