package com.cg.bankapp.dao;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cg.bankapp.pojo.Transaction;

public interface TransactionDao extends JpaRepository<Transaction, Long> {
	@Query("from Transaction where AccountNumber = :accntno")
	List<Transaction> findById(@Param("accntno") long account);

	static List<Transaction> printTransaction(long accno) {
		return null;
	}
}