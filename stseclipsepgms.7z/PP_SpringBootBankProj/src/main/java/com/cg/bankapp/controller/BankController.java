package com.cg.bankapp.controller;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.bankapp.exception.BankingException;
import com.cg.bankapp.pojo.Bank;
import com.cg.bankapp.pojo.Transaction;
import com.cg.bankapp.service.BankService;
@RestController
public class BankController {
	@Autowired
	BankService bankService;

	@RequestMapping(value = "/addaccount", method = RequestMethod.POST)
	public Bank addBankAccount(@RequestBody Bank bank) throws BankingException {

		return bankService.createAccount(bank);

	}

	@RequestMapping("showbalance/{accountId}")
	public double showBalance(@PathVariable int accountId) throws BankingException {
		return bankService.showBalance(accountId);
	}

	@RequestMapping(value = "depositamount/{accountId}/{depositamt}", method = RequestMethod.PUT)
	public double depositAmount(@PathVariable Integer accountId, @PathVariable Integer depositamt)
			throws BankingException {
		try {
			bankService.depositAmount(accountId, depositamt);
			return bankService.showBalance(accountId);
		} catch (Exception ex) {
			return 0;
		}

	}

	@RequestMapping(value = "withdrawamount/{accountId}/{withdrawamt}", method = RequestMethod.PUT)
	public double withdrawAmount(@PathVariable Integer accountId, @PathVariable Integer withdrawamt)
			throws BankingException {
		try {
			bankService.withdrawAmount(accountId, withdrawamt);
			return bankService.showBalance(accountId);
		} catch (Exception ex) {
			return 0;
		}
	}

	@RequestMapping(value = "transferamount/{FromAccount}/{ToAccount}/{amount}", method = RequestMethod.GET)
	public double cashTransfer(@PathVariable int FromAccount, @PathVariable int ToAccount, @PathVariable double amount)
			throws BankingException {
		try {
			bankService.transferAmount(FromAccount, ToAccount, amount);
			return bankService.showBalance(FromAccount);
		} catch (Exception ex) {
			return 0;
		}
	}

	
	@RequestMapping(value = "/printstatement/{accno}", method = RequestMethod.GET)
	public Transaction printTransaction(@PathVariable long accno) {
		return bankService.PrintTransactionStat(accno);
	}
}
