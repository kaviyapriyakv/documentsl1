package com.cg.bankapp.service;
import com.cg.bankapp.exception.BankingException;
import com.cg.bankapp.pojo.Bank;
import com.cg.bankapp.pojo.Transaction;
public interface BankService {
	public Bank createAccount(Bank bank) throws BankingException;

	public double showBalance(int accountId) throws BankingException;

	public double depositAmount(int accountId, double deposit) throws BankingException;

	public double withdrawAmount(int accountId, double withdraw) throws BankingException;

	public void gettingDetailsToLogin(String username, String password) throws BankingException;

	public Bank transferAmount(int source, int destination, double money) throws BankingException;

	public Transaction PrintTransactionStat(long accno);
}
