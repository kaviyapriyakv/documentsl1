package com.cg.bankapp.service;

import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;

import com.cg.bankapp.dao.BankDao;
import com.cg.bankapp.dao.TransactionDao;
import com.cg.bankapp.exception.BankingException;
import com.cg.bankapp.pojo.Bank;
import com.cg.bankapp.pojo.Transaction;
@Service
public class BankServiceExe implements BankService {
	@Autowired
	BankDao bankDao;
	@Autowired
	TransactionDao transactionDao;

	public Bank gettingDetails(int accountId) throws BankingException {
		try {
			return bankDao.findById(accountId).get();
		} catch (Exception ex) {
			throw new BankingException(ex.getMessage());
		}
	}

	@Override
	public Bank createAccount(Bank bank) throws BankingException {
		try {
			return bankDao.save(bank);
		} catch (Exception ex) {
			throw new BankingException(ex.getMessage());
		}
	}
	@Override
	public double showBalance(int accountId) throws BankingException {
		try {
			Bank bank = bankDao.findById(accountId).get();
			return bank.getBalance();
		} catch (Exception ex) {
			throw new BankingException(ex.getMessage());
		}
	}

	public double depositAmount(int accountId, double amount) throws BankingException {
		try {
			Optional<Bank> optnl = bankDao.findById(accountId);
			Transaction transaction = new Transaction();
			Bank depo = optnl.get();
			depo.setBalance(optnl.get().getBalance() + amount);
			transaction.setTransactionType("Deposit");
			transaction.setAccountNumber(accountId);
			transaction.setAmount(amount);
			transactionDao.save(transaction);
			bankDao.save(depo);
			return bankDao.findById(accountId).get().getBalance();
		} catch (Exception e) {
			throw new BankingException(e.getMessage());
		}

	}

	@Override
	public double withdrawAmount(int accountId, double wdamount) throws BankingException {
		try {
			Optional<Bank> optnl = bankDao.findById(accountId);
			Transaction transaction = new Transaction();
			if (optnl.isPresent()) {
				Bank wda = optnl.get();
				wda.setBalance(optnl.get().getBalance() - wdamount);
				transaction.setAccountNumber(accountId);
				transaction.setAmount(wdamount);
				transaction.setTransactionType("Withdraw");
				transactionDao.save(transaction);
				bankDao.save(wda);
				return bankDao.findById(accountId).get().getBalance();
			} else {
				throw new BankingException("Customer with accountnumber " + accountId + " does not exit");
			}

		} catch (Exception e) {
			throw new BankingException(e.getMessage());
		}
	}

	@Override
	public Bank transferAmount(int source, int destination, double amountT) throws BankingException {
		try {
			Optional<Bank> optnl1 = bankDao.findById(source);
			Optional<Bank> optnl2 = bankDao.findById(destination);
			Transaction transaction = new Transaction();
			Transaction transctn1 = new Transaction();
			if (optnl1.isPresent() && optnl2.isPresent()) {
				Bank deposit = optnl1.get();
				Bank credit = optnl2.get();
				deposit.setBalance(deposit.getBalance() - amountT);
				credit.setBalance(credit.getBalance() + amountT);
				bankDao.save(deposit);
				bankDao.save(credit);
				transaction.setAccountNumber(source);
				transaction.setAmount(amountT);
				transaction.setTransactionType("Transfer");
				transactionDao.save(transaction);
				transctn1.setAccountNumber(destination);
				transctn1.setTransactionType("transfer");
				transctn1.setAmount(amountT);
				transactionDao.save(transctn1);
				return bankDao.findById(source).get();
			} else {
				throw new BankingException("Customer with accountnumber " + source + " does not exit");
			}
		} catch (Exception e) {
			throw new BankingException(e.getMessage());
		}
	}

	@Override
	public void gettingDetailsToLogin(String username, String password) throws BankingException {

	}


	@Override
	public Transaction PrintTransactionStat(long accno) {
		// TODO Auto-generated method stub
		Transaction transaction = transactionDao.findById(accno).get(0);
		return transaction;

	}

}
