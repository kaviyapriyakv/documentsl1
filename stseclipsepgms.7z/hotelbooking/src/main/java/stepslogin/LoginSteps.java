package stepslogin;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.DataTable;
import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import junit.framework.Assert;

public class LoginSteps {
	WebDriver driver;
	 WebElement searchelement;
	@Given("^user is on hotelapplication  Login form$")
	public void user_is_on_hotelapplication_Login_form() {
	    // Write code here that turns the phrase above into concrete actions
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\KPRIYAKV\\chromedriver_win32\\chromedriver.exe");
		 driver = new ChromeDriver();
		driver.get("file:///C:/Users/KPRIYAKV/JEE%20Full%20stack/Module%205/hotelBooking/login.html");
		 
	    //throw new PendingException();
	}

	@When("^user enters username and password$")
	public void user_enters_username_and_password() {
	    // Write code here that turns the phrase above into concrete actions		
	        driver.findElement(By.xpath("//*[@id=\"mainCnt\"]/div/div[1]/form/table/tbody/tr[2]/td[2]/input")).sendKeys("capgemini");	       
	        driver.findElement(By.xpath("//*[@id=\"mainCnt\"]/div/div[1]/form/table/tbody/tr[3]/td[2]/input")).sendKeys("capg1234");
	        
	    //throw new PendingException();
	}
	@When("^user clicks on submit$")
	public void user_clicks_on_submit() {
	    // Write code here that turns the phrase above into concrete actions
        driver.findElement(By.xpath("//*[@id=\"mainCnt\"]/div/div[1]/form/table/tbody/tr[4]/td[2]/input")).click();
		//throw new PendingException();
	}

	
	@Then("^Home page must appear$")
	public void home_page_must_appear() {
	    // Write code here that turns the phrase above into concrete actions
		Assert.assertEquals(driver.getTitle(), "Hotel Booking");
	   // throw new PendingException();
	}
	@Given("^user is on hotelbooking form$")
	public void user_is_on_hotelbooking_form() {
	    // Write code here that turns the phrase above into concrete actions
		
	    //throw new PendingException();
	}

	/*@When("^user enters firstname and lastname$")
	public void user_enters_firstname_and_lastname(DataTable arg1) {
		 List<List<String>> list =arg1.raw();
			
		  driver.findElement(By.xpath("//*[@id=\"mountRoot\"]/div/div/div/form/fieldset[1]/div[1]/input")).sendKeys(list.get(0).get(0));
		  driver.findElement(By.xpath("//*[@id=\'mountRoot\']/div/div/div/form/fieldset[1]/div[2]/input")).sendKeys(list.get(0).get(1));*/
	    //throw new PendingException();
	}

	

