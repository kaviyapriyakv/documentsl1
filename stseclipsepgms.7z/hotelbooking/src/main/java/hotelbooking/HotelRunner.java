package hotelbooking;
import org.junit.runner.RunWith;
import cucumber.api.CucumberOptions; 
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(features="feature",glue="stepslogin",format="json:test-output/cucumber/json",dryRun=false) 

public class HotelRunner {
	
}
