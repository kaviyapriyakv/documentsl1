package loginpojo;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
@FindBy(xpath="//span[contains(text(),'Profile')]")

public class Loginpage {
	
	public Loginpage(WebDriver driver) {
		// TODO Auto-generated constructor stub
		PageFactory.initElements(driver,this);
	}
	@FindBy(xpath="//*[@id=\"Text24\"]")
	WebElement cid ;
	public void candidateId() {
		// TODO Auto-generated method stub\
		cid.click();
		cid.sendKeys("123");			
	
	}
	@FindBy(xpath="//*[@id=\"Button4\"]")
	WebElement submit ;
	public void clickSubmit() {
		// TODO Auto-generated method stub
		submit.click();
		
	}
	@FindBy(xpath="//*[@id=\"Text1\"]")
	WebElement title ;
	public void comedyTitle() {
		// TODO Auto-generated method stub
		title.sendKeys("standup");
		//title.click();
		
	}
	@FindBy(xpath="//*[@id=\"Text12\"]")
	WebElement rdate ;
	public void releaseDate() {
		// TODO Auto-generated method stub
		rdate.sendKeys("23/10/2019");
		
		
	}
	@FindBy(xpath="//*[@id=\"Text14\"]")
	WebElement comedian ;
	public void showComedian() {
		// TODO Auto-generated method stub
		comedian.sendKeys("deena");
		
	}
	@FindBy(xpath="//*[@id=\"Text15\"]")
	WebElement duration ;
	public void showDuration() {
		// TODO Auto-generated method stub
		duration.sendKeys("three hours");
	}
	@FindBy(xpath="//*[@id=\"Select12\"]")
    WebElement language;
	public void selectLanguage() {
		// TODO Auto-generated method stub
		 Select s=new Select(language);
         s.selectByVisibleText("English");
        
	}
	 @FindBy(xpath="//*[@id=\"Select9\"]")
	   WebElement rating;
	public void showRating() {
		// TODO Auto-generated method stub
		 Select s1=new Select(rating);
         s1.selectByVisibleText("1");
		
	}
	/*@FindBy(xpath="//*[@id=\"Button5\"]")
	WebElement reset ;
	public void clickReset() {
		// TODO Auto-generated method stub
		reset.click();
	}
	*/
	@FindBy(xpath="//*[@id=\"Button4\"]")
	WebElement submit1 ;
	@FindBy(xpath="//*[@id=\"Select12\"]")
    WebElement language1;
	@FindBy(xpath="//*[@id=\"Select9\"]")
	 WebElement rating1;
	@FindBy(xpath="//*[@id=\"Text1\"]")
	WebElement title1 ;
	@FindBy(xpath="//*[@id=\"Text12\"]")
	WebElement rdate1 ;
	@FindBy(xpath="//*[@id=\"Text14\"]")
	WebElement comedian1 ;
	@FindBy(xpath="//*[@id=\"Text15\"]")
	WebElement duration1 ;	
	@FindBy(xpath="//*[@id=\"Text24\"]")
	WebElement cid1 ;
	public void emptyCredentials() {
		// TODO Auto-generated method stub
		cid1.click();
		cid1.sendKeys("");
		title1.sendKeys("dsdfdf");
		rdate1.sendKeys("12/12/98");
		comedian1.sendKeys("sdf");
		duration1.sendKeys("twohrs");
		Select s2=new Select(language1);
        s2.selectByVisibleText("English");
        Select s3=new Select(rating1);
        s3.selectByVisibleText("1");
		submit1.click();
	}
	

	
	
	
	
	
	
}
