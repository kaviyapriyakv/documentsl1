package stepdef;

import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.DataTable;
import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

import loginpojo.Loginpage;



public class LoginSteps {
	WebDriver driver;
	WebElement profile;
	Loginpage login;
	@Given("^user is on Online Comedy Show Video Management System Login page$")
	public void user_is_on_Online_Comedy_Show_Video_Management_System_Login_page() {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\KPRIYAKV\\chromedriver_win32\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("file:///C:/Users/KPRIYAKV/Downloads/ComedyShow.html");
		Assert.assertEquals(driver.getTitle(),"Add ComedyShow Form");
		login = new Loginpage(driver);
		
		
	    //throw new PendingException();
	}

	@When("^user enters ComedyShow ID$")
public void user_enters_ComedyShow_ID() {
		login.candidateId();
		//login.clickSubmit();
	    //throw new PendingException();
	}
	@When("^user enters ComedyShow Title$")
	public void user_enters_ComedyShow_Title() {
	    // Write code here that turns the phrase above into concrete actions
		login.comedyTitle();
		//login.clickSubmit();
		
	    //throw new PendingException();
	}

	@When("^user enters Release Date$")
	public void user_enters_Release_Date() {
	    // Write code here that turns the phrase above into concrete actions
		login.releaseDate();
		//login.clickSubmit();
	    //throw new PendingException();
	}

	@When("^user enters Comedian$")
	public void user_enters_Comedian() {
	    // Write code here that turns the phrase above into concrete actions
		login.showComedian();
		//login.clickSubmit();
	    //throw new PendingException();
	}

	@When("^user enters ComedyShow Duration$")
	public void user_enters_ComedyShow_Duration() {
	    // Write code here that turns the phrase above into concrete actions
		login.showDuration();
		//login.clickSubmit();
	   // throw new PendingException();
		
	}
	@When("^user enters  Language$")
	public void user_enters_Language() {
	    // Write code here that turns the phrase above into concrete actions
		login.selectLanguage();
		//login.clickSubmit();
	   // throw new PendingException();
	}

	@When("^user enters  ComedyShow Rating$")
	public void user_enters_ComedyShow_Rating() {
	    // Write code here that turns the phrase above into concrete actions
		login.showRating();
		//login.clickSubmit();
	   // throw new PendingException();
	}
	
	/*@When("^user enters reset$")
	public void user_enters_reset() {
	    // Write code here that turns the phrase above into concrete actions
		login.clickReset();
	    //throw new PendingException();
	}*/
	
	
	
	@When("^user clicks on submit$")
	public void user_clicks_on_submit() {
	    // Write code here that turns the phrase above into concrete actions
		   login.clickSubmit();
		   driver.switchTo().alert().accept();
		   try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		  
	    //throw new PendingException();
	}

	@Then("^Home page must appear$")
	public void home_page_must_appear() {
	    // Write code here that turns the phrase above into concrete actions
		Assert.assertEquals(driver.getTitle(),"Add ComedyShow Form");
	    //throw new PendingException();
	}

	@When("^user enters empty ComedyShow ID$")
	public void user_enters_empty_ComedyShow_ID() {
	  
		login.emptyCredentials();
		  driver.switchTo().alert().accept();
	    //throw new PendingException();
	}

	@When("^user enters empty ComedyShow Title$")
	public void user_enters_empty_ComedyShow_Title() {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
		login.emptyCredentials();
		  driver.switchTo().alert().accept();
	}

	@When("^user enters empty Release Date$")
	public void user_enters_empty_Release_Date() {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		login.emptyCredentials();
		  driver.switchTo().alert().accept();
	}

	@When("^user enters empty Comedian$")
	public void user_enters_empty_Comedian() {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
	login.emptyCredentials();
	  driver.switchTo().alert().accept();
	}

	@When("^user enters empty ComedyShow Duration$")
	public void user_enters_empty_ComedyShow_Duration() {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		login.emptyCredentials();
		  driver.switchTo().alert().accept();
	}

	@When("^user enters empty Language$")
	public void user_enters_empty_Language() {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		login.emptyCredentials();
		  driver.switchTo().alert().accept();
	}

	@When("^user enters empty ComedyShow Rating$")
	public void user_enters_empty_ComedyShow_Rating() {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		login.emptyCredentials();
		  driver.switchTo().alert().accept();
	}

	@When("^user clicks on submita$")
	public void user_clicks_on_submita() {
	    // Write code here that turns the phrase above into concrete actions
		login.emptyCredentials();
		driver.switchTo().alert().accept();
	    throw new PendingException();
	  
	}




}
