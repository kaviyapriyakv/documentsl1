package com.cg.cartest.stepdefinition;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class LoginPage {

	public LoginPage(WebDriver driver) {
		// TODO Auto-generated constructor stub
		PageFactory.initElements(driver, this);
	}
	@FindBy(xpath="//*[@id=\"fname\"]")
	WebElement firstname;
	@FindBy(xpath="//*[@id=\"lname\"]")
	WebElement lastname;
	
	@FindBy(xpath="//*[@id=\"emails\"]")
	WebElement email;
	
	@FindBy(xpath="//*[@id=\"mobile\"]")
	WebElement mobile;
	
	@FindBy(name="D5")
	WebElement citypreference;
	
	@FindBy(name="D6")
	WebElement carbody;
	
	@FindBy(name="D4")
	WebElement fuel;
	
	@FindBy(name="D3")
	WebElement seating;
	

	
	@FindBy(xpath="//*[@id=\"enqdetails\"]")
	WebElement enquirydetails;
	
	@FindBy(xpath="//*[@id=\"Submit1\"]")
	WebElement submit;
	
	
	public void enterFirstname() {
		// TODO Auto-generated method stub
		firstname.click();
		firstname.sendKeys("");
		submit.click();
		
	}

	public void enterLastname() {
		// TODO Auto-generated method stub
		firstname.sendKeys("lakshmi");
		lastname.sendKeys("");
		submit.click();
	}

	public void enterEmail() {
		// TODO Auto-generated method stub
		firstname.clear();
		firstname.sendKeys("lakshmi");
		lastname.sendKeys("priya");
		email.sendKeys("");
		submit.click();
	}

	public void enterMobile() {
		// TODO Auto-generated method stub
		// TODO Auto-generated method stub
		firstname.clear();
	    firstname.sendKeys("lakshmi");
	    lastname.clear();
		lastname.sendKeys("priya");
		email.sendKeys("lakshmi@gmail.com");
		mobile.sendKeys("asd");
		submit.click();
		
	}

	public void MobileW() {
		// TODO Auto-generated method stub
		firstname.clear();
		firstname.sendKeys("lakshmi");
		lastname.clear();
		lastname.sendKeys("priya");
		email.clear();
		email.sendKeys("lakshmi@gmail.com");
		mobile.clear();
		mobile.sendKeys("98764455");
		submit.click();
	}

	public void selectCitypreference() {
		// TODO Auto-generated method stub
		firstname.clear();
		firstname.sendKeys("lakshmi");
		lastname.clear();
		lastname.sendKeys("priya");
		email.clear();
		email.sendKeys("lakshmi@gmail.com");
		mobile.clear();
		mobile.sendKeys("9876445523");
		submit.click();
	}

	public void selectCarbodytype() {
		// TODO Auto-generated method stub
		firstname.clear();
		firstname.sendKeys("lakshmi");
		lastname.clear();
		lastname.sendKeys("priya");
		email.clear();
		email.sendKeys("lakshmi@gmail.com");
		mobile.clear();
		mobile.sendKeys("9876445523");
		Select select = new Select(citypreference);
		select.selectByVisibleText("Chennai");
		submit.click();
	}

	public void selectFuelType() {
		// TODO Auto-generated method stub
		firstname.clear();
		firstname.sendKeys("lakshmi");
		lastname.clear();
		lastname.sendKeys("priya");
		email.clear();
		email.sendKeys("lakshmi@gmail.com");
		mobile.clear();
		mobile.sendKeys("9876445523");
		citypreference.click();
		Select select = new Select(citypreference);
		select.selectByVisibleText("Chennai");
		Select select1 = new Select(carbody);
		select1.selectByVisibleText("SUV");
		
		submit.click();
	}

	public void selectSeating() {
		// TODO Auto-generated method stub
		firstname.clear();
		firstname.sendKeys("lakshmi");
		lastname.clear();
		lastname.sendKeys("priya");
		email.clear();
		email.sendKeys("lakshmi@gmail.com");
		mobile.clear();
		mobile.sendKeys("9876445523");
		Select select = new Select(citypreference);
		select.selectByVisibleText("Chennai");
		Select select1 = new Select(carbody);
		select1.selectByVisibleText("SUV");
		Select select2 = new Select(fuel);
		select2.selectByVisibleText("Petrol");
		submit.click();
	}
	
	public void enquiryDetails() {
		// TODO Auto-generated method stub
		firstname.clear();
		firstname.sendKeys("lakshmi");
		lastname.clear();
		lastname.sendKeys("priya");
		email.clear();
		email.sendKeys("lakshmi@gmail.com");
		mobile.clear();
		mobile.sendKeys("9876445523");
		Select select = new Select(citypreference);
		select.selectByVisibleText("Chennai");
		Select select1 = new Select(carbody);
		select1.selectByVisibleText("SUV");
		Select select2 = new Select(fuel);
		select2.selectByVisibleText("Petrol");
		Select select3 = new Select(seating);
		select3.selectByVisibleText("6-8");
		submit.click();
	
	}

	public void filledEnquiryDetails() {
		// TODO Auto-generated method stub
		firstname.sendKeys("lakshmi");
		lastname.sendKeys("priya");
		email.sendKeys("lakshmi@gmail.com");
		mobile.clear();
		mobile.sendKeys("9876445523");
		Select select = new Select(citypreference);
		select.selectByVisibleText("Chennai");
		Select select1 = new Select(carbody);
		select1.selectByVisibleText("SUV");
		Select select2 = new Select(fuel);
		select2.selectByVisibleText("Petrol");
		Select select3 = new Select(seating);
		select3.selectByVisibleText("6-8");
		enquirydetails.sendKeys("to buy a new car");
		submit.click();
	}

	
	
}
