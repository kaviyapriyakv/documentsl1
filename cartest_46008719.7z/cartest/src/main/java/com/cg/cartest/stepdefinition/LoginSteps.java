package com.cg.cartest.stepdefinition;

import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class LoginSteps {
	WebDriver driver;
	LoginPage login;
	@Given("^user is on Customer Enquiry Form page for online car search$")
	public void user_is_on_Customer_Enquiry_Form_page_for_online_car_search() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\KPRIYAKV\\chromedriver_win32\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.get("file:///C:/Users/KPRIYAKV/Documents/online_car_search.html");
		login = new LoginPage(driver);
		Assert.assertEquals("Online Car Search",driver.getTitle());
		Thread.sleep(5000); 
	}

	@When("^user clicks Enquire Now button without filling firstname$")
	public void user_clicks_Enquire_Now_button_without_filling_firstname() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		login.enterFirstname();
		 
	}

	@Then("^Alert should display 'First Name must be filled out'$")
	public void alert_should_display_First_Name_must_be_filled_out() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		 Assert.assertEquals("First Name must be filled out",driver.switchTo().alert().getText());
		 driver.switchTo().alert().accept();
	}

	@When("^user clicks Enquire Now button without filling lastname$")
	public void user_clicks_Enquire_Now_button_without_filling_lastname() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		login.enterLastname();
		
	   
	}

	@Then("^Alert should display 'Last Name must be filled out'$")
	public void alert_should_display_Last_Name_must_be_filled_out() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		 Assert.assertEquals("Last Name must be filled out",driver.switchTo().alert().getText());
		 driver.switchTo().alert().accept();
	}

	@When("^user clicks Enquire Now button without filling Email$")
	public void user_clicks_Enquire_Now_button_without_filling_Email() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		login.enterEmail();
	}

	@Then("^Alert should display 'Email must be filled out'$")
	public void alert_should_display_Email_must_be_filled_out() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		 Assert.assertEquals("Email must be filled out",driver.switchTo().alert().getText());
		 driver.switchTo().alert().accept();
	}

	@When("^user clicks Enquire Now button without filling Mobile$")
	public void user_clicks_Enquire_Now_button_without_filling_Mobile() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		login.enterMobile();
	}

	@Then("^Alert should display 'Mobile must be filled out'$")
	public void alert_should_display_Mobile_must_be_filled_out() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		 Assert.assertEquals("Enter numeric value",driver.switchTo().alert().getText());
		 driver.switchTo().alert().accept();
	}

	@When("^user clicks Enquire Now button with wrongdata in Mobile$")
	public void user_clicks_Enquire_Now_button_with_wrongdata_in_Mobile() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		login.MobileW();
	}

	@Then("^Alert should display 'Enter ten digit Mobile Number'$")
	public void alert_should_display_Enter_ten_digit_Mobile_Number() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Assert.assertEquals("Enter 10 digit Mobile number",driver.switchTo().alert().getText());
		 driver.switchTo().alert().accept();
	}
	    
	@When("^user clicks Enquire Now button without selecting city preference$")
	public void user_clicks_Enquire_Now_button_without_selecting_city_preference() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		login.selectCitypreference();
	}

	@Then("^Alert should display 'City should be selected'$")
	public void alert_should_display_City_should_be_selected() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		 Assert.assertEquals("City should be selected",driver.switchTo().alert().getText());
		 driver.switchTo().alert().accept();
	}

	@When("^user clicks Enquire Now button without selecting Car Body type$")
	public void user_clicks_Enquire_Now_button_without_selecting_Car_Body_type() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		login.selectCarbodytype();
	}

	@Then("^Alert should display 'Car Body Type should be selected'$")
	public void alert_should_display_Car_Body_Type_should_be_selected() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		
		 Assert.assertEquals("Car Body Type Should be selected",driver.switchTo().alert().getText());
		 driver.switchTo().alert().accept();
	}

	@When("^user clicks Enquire Now button without selecting Fuel Type$")
	public void user_clicks_Enquire_Now_button_without_selecting_Fuel_Type() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		login.selectFuelType();
	}

	@Then("^Alert should display 'Fuel Type should be selected'$")
	public void alert_should_display_Fuel_Type_should_be_selected() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		 Assert.assertEquals("Fuel Type should be selected",driver.switchTo().alert().getText());
		 driver.switchTo().alert().accept();
	}

	@When("^user clicks Enquire Now button without selecting Seating Capacity$")
	public void user_clicks_Enquire_Now_button_without_selecting_Seating_Capacity() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		login.selectSeating();
	}

	@Then("^Alert should display 'Seating Capacity should be selected'$")
	public void alert_should_display_Seating_Capacity_should_be_selected() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		 Assert.assertEquals("Seating Capacity should be selected",driver.switchTo().alert().getText());
		 driver.switchTo().alert().accept();
	}

	@When("^user clicks Enquire Now button without filling Enquiry Details$")
	public void user_clicks_Enquire_Now_button_without_filling_Enquiry_Details() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		login.enquiryDetails();
	}

	@Then("^Alert should display 'Enquiry details must be filled out'$")
	public void alert_should_display_Enquiry_details_must_be_filled_out() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		 Assert.assertEquals("Enquiry details must be filled out",driver.switchTo().alert().getText());
		 driver.switchTo().alert().accept();
	}

	@When("^the user clicks the Enquiry Now button with entering all details$")
	public void the_user_clicks_the_Enquiry_Now_button_with_entering_all_details() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		login.filledEnquiryDetails();
	}

	@Then("^'Thank you for submitting the online recipe class enquiry' message is displayed$")
	public void thank_you_for_submitting_the_online_recipe_class_enquiry_message_is_displayed() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		
		Assert.assertEquals("Thank you for submitting the online Car Search Details.",driver.switchTo().alert().getText());
				 driver.switchTo().alert().accept();
	}


}
